# WordPress MySQL database migration
#
# Generated: Saturday 6. May 2023 08:45 UTC
# Hostname: localhost
# Database: `lindo`
# URL: //lindo
# Path: C:\\OpenServer\\domains\\lindow
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_trp_dictionary_uz_uz_ru_ru, wp_trp_gettext_original_meta, wp_trp_gettext_original_strings, wp_trp_gettext_ru_ru, wp_trp_gettext_uz_uz, wp_trp_original_meta, wp_trp_original_strings, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, language_switcher, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://lindo', 'yes'),
(2, 'home', 'http://lindo', 'yes'),
(3, 'blogname', 'lindo', 'yes'),
(4, 'blogdescription', 'Ещё один сайт на WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'xibroxim11@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '3', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:110:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:45:"language_switcher/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"language_switcher/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"language_switcher/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"language_switcher/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"language_switcher/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"language_switcher/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"language_switcher/([^/]+)/embed/?$";s:50:"index.php?language_switcher=$matches[1]&embed=true";s:38:"language_switcher/([^/]+)/trackback/?$";s:44:"index.php?language_switcher=$matches[1]&tb=1";s:46:"language_switcher/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?language_switcher=$matches[1]&paged=$matches[2]";s:53:"language_switcher/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?language_switcher=$matches[1]&cpage=$matches[2]";s:42:"language_switcher/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?language_switcher=$matches[1]&page=$matches[2]";s:34:"language_switcher/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"language_switcher/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"language_switcher/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"language_switcher/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"language_switcher/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"language_switcher/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:37:"translatepress-multilingual/index.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '3', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'lindo', 'yes'),
(41, 'stylesheet', 'lindo', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '0', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1698914550', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:6:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:10:"loco_admin";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:10:"translator";a:2:{s:4:"name";s:10:"Translator";s:12:"capabilities";a:2:{s:4:"read";b:1;s:10:"loco_admin";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:6:{i:1683364372;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1683396234;a:5:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683396269;a:3:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683396276;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1683828234;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1664389614;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(125, 'recovery_keys', 'a:0:{}', 'yes'),
(126, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}}', 'yes'),
(149, 'db_upgraded', '', 'yes'),
(160, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:20:"xibroxim11@gmail.com";s:7:"version";s:5:"6.0.3";s:9:"timestamp";i:1666202860;}', 'no'),
(163, 'finished_updating_comment_type', '1', 'yes'),
(164, 'can_compress_scripts', '1', 'no'),
(165, 'current_theme', 'lindoStyle', 'yes'),
(166, 'theme_mods_lindo', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(167, 'theme_switched', '', 'yes'),
(172, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(173, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(306, 'recently_activated', 'a:0:{}', 'yes'),
(311, 'acf_version', '6.0.2', 'yes'),
(314, 'category_children', 'a:0:{}', 'yes'),
(328, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(895, 'trp_settings', 'a:15:{s:16:"default-language";s:5:"uz_UZ";s:17:"publish-languages";a:2:{i:0;s:5:"uz_UZ";i:1;s:5:"ru_RU";}s:21:"translation-languages";a:2:{i:0;s:5:"uz_UZ";i:1;s:5:"ru_RU";}s:9:"url-slugs";a:2:{s:5:"uz_UZ";s:5:"uz_uz";s:5:"ru_RU";s:2:"ru";}s:22:"native_or_english_name";s:12:"english_name";s:36:"add-subdirectory-to-default-language";s:2:"no";s:30:"force-language-to-custom-links";s:3:"yes";s:17:"shortcode-options";s:16:"flags-full-names";s:12:"menu-options";s:16:"flags-full-names";s:14:"trp-ls-floater";s:3:"yes";s:15:"floater-options";s:16:"flags-full-names";s:13:"floater-color";s:4:"dark";s:16:"floater-position";s:12:"bottom-right";s:21:"trp-ls-show-poweredby";s:2:"no";s:41:"translation-languages-formality-parameter";a:2:{s:5:"uz_UZ";s:7:"default";s:5:"ru_RU";s:7:"default";}}', 'yes'),
(896, 'trp_db_stored_data', 'a:3:{s:17:"install_timestamp";i:1674342565;s:27:"gettext_plural_forms_header";a:2:{s:5:"ru_RU";s:129:"nplurals=3; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : ((n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14)) ? 1 : 2);";s:5:"uz_UZ";s:21:"nplurals=1; plural=0;";}s:36:"trp_site_meets_conditions_for_review";b:1;}', 'yes'),
(897, 'trp_plugin_version', '2.4.5', 'yes'),
(900, 'trp_plugin_optin', 'no', 'yes'),
(901, 'trp_advanced_settings', 'a:24:{s:39:"show_dynamic_content_before_translation";s:2:"no";s:27:"disable_dynamic_translation";s:2:"no";s:15:"fix_broken_html";s:2:"no";s:26:"strip_gettext_post_content";s:2:"no";s:23:"strip_gettext_post_meta";s:2:"no";s:23:"exclude_gettext_strings";a:2:{s:6:"string";a:0:{}s:6:"domain";a:0:{}}s:33:"exclude_words_from_auto_translate";a:1:{s:5:"words";a:0:{}}s:22:"skip_dynamic_selectors";a:1:{s:8:"selector";a:0:{}}s:27:"exclude_translate_selectors";a:1:{s:8:"selector";a:0:{}}s:44:"exclude_selectors_from_automatic_translation";a:1:{s:8:"selector";a:0:{}}s:42:"disable_post_container_tags_for_post_title";s:2:"no";s:44:"disable_post_container_tags_for_post_content";s:2:"no";s:39:"disable_translation_for_gettext_strings";s:2:"no";s:38:"show_regular_tab_in_string_translation";s:2:"no";s:22:"hreflang_remove_locale";s:0:"";s:23:"html_lang_remove_locale";s:0:"";s:27:"force_slash_at_end_of_links";s:2:"no";s:27:"enable_numerals_translation";s:2:"no";s:25:"disable_languages_sitemap";s:2:"no";s:24:"enable_hreflang_xdefault";s:0:"";s:46:"show_opposite_flag_language_switcher_shortcode";s:2:"no";s:41:"open_language_switcher_shortcode_on_click";s:2:"no";s:20:"plugin_optin_setting";s:2:"no";s:15:"custom_language";a:6:{s:11:"cuslangcode";a:0:{}s:11:"cuslangname";a:0:{}s:13:"cuslangnative";a:0:{}s:10:"cuslangiso";a:0:{}s:11:"cuslangflag";a:0:{}s:12:"cuslangisrtl";a:0:{}}}', 'yes'),
(912, 'loco_recent', 'a:4:{s:1:"c";s:21:"Loco_data_RecentItems";s:1:"v";i:0;s:1:"d";a:1:{s:6:"bundle";a:1:{s:4:"core";i:1674343118;}}s:1:"t";i:1674343118;}', 'no'),
(1163, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1683362723;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=657 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(9, 7, '_edit_lock', '1664389833:1'),
(10, 7, '_wp_page_template', 'index.php'),
(11, 10, '_edit_lock', '1674953609:1'),
(12, 10, '_wp_page_template', 'pageAllProducts.php'),
(14, 15, '_edit_last', '1'),
(15, 15, '_edit_lock', '1666208002:1'),
(71, 29, '_edit_lock', '1665338629:1'),
(83, 34, '_wp_attached_file', '2022/10/3.png'),
(84, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2174;s:6:"height";i:2018;s:4:"file";s:13:"2022/10/3.png";s:8:"filesize";i:2322095;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:13:"3-300x278.png";s:5:"width";i:300;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71075;}s:5:"large";a:5:{s:4:"file";s:14:"3-1024x951.png";s:5:"width";i:1024;s:6:"height";i:951;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:566349;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25588;}s:12:"medium_large";a:5:{s:4:"file";s:13:"3-768x713.png";s:5:"width";i:768;s:6:"height";i:713;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:343631;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"3-1536x1426.png";s:5:"width";i:1536;s:6:"height";i:1426;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1158197;}s:9:"2048x2048";a:5:{s:4:"file";s:15:"3-2048x1901.png";s:5:"width";i:2048;s:6:"height";i:1901;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1927275;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(85, 35, '_wp_attached_file', '2022/10/4.png'),
(86, 35, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2006;s:6:"height";i:1564;s:4:"file";s:13:"2022/10/4.png";s:8:"filesize";i:1851889;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"4-300x234.png";s:5:"width";i:300;s:6:"height";i:234;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:63874;}s:5:"large";a:5:{s:4:"file";s:14:"4-1024x798.png";s:5:"width";i:1024;s:6:"height";i:798;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:528839;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28086;}s:12:"medium_large";a:5:{s:4:"file";s:13:"4-768x599.png";s:5:"width";i:768;s:6:"height";i:599;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:321896;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"4-1536x1198.png";s:5:"width";i:1536;s:6:"height";i:1198;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1059364;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(87, 36, '_wp_attached_file', '2022/10/5.png'),
(88, 36, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2042;s:6:"height";i:1607;s:4:"file";s:13:"2022/10/5.png";s:8:"filesize";i:2013898;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"5-300x236.png";s:5:"width";i:300;s:6:"height";i:236;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:72757;}s:5:"large";a:5:{s:4:"file";s:14:"5-1024x806.png";s:5:"width";i:1024;s:6:"height";i:806;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:590916;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:31758;}s:12:"medium_large";a:5:{s:4:"file";s:13:"5-768x604.png";s:5:"width";i:768;s:6:"height";i:604;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:359716;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"5-1536x1209.png";s:5:"width";i:1536;s:6:"height";i:1209;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1199102;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(89, 37, '_wp_attached_file', '2022/10/6.png'),
(90, 37, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2028;s:6:"height";i:1942;s:4:"file";s:13:"2022/10/6.png";s:8:"filesize";i:2496271;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"6-300x287.png";s:5:"width";i:300;s:6:"height";i:287;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77177;}s:5:"large";a:5:{s:4:"file";s:14:"6-1024x981.png";s:5:"width";i:1024;s:6:"height";i:981;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:642063;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"6-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25583;}s:12:"medium_large";a:5:{s:4:"file";s:13:"6-768x735.png";s:5:"width";i:768;s:6:"height";i:735;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:384409;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"6-1536x1471.png";s:5:"width";i:1536;s:6:"height";i:1471;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1355030;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(91, 38, '_wp_attached_file', '2022/10/7.png'),
(92, 38, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1801;s:6:"height";i:1492;s:4:"file";s:13:"2022/10/7.png";s:8:"filesize";i:1538038;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"7-300x249.png";s:5:"width";i:300;s:6:"height";i:249;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:60171;}s:5:"large";a:5:{s:4:"file";s:14:"7-1024x848.png";s:5:"width";i:1024;s:6:"height";i:848;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:512783;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"7-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25430;}s:12:"medium_large";a:5:{s:4:"file";s:13:"7-768x636.png";s:5:"width";i:768;s:6:"height";i:636;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:306862;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"7-1536x1272.png";s:5:"width";i:1536;s:6:"height";i:1272;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1049479;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(93, 39, '_wp_attached_file', '2022/10/8.png'),
(94, 39, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2101;s:6:"height";i:2107;s:4:"file";s:13:"2022/10/8.png";s:8:"filesize";i:2080941;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:13:"8-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:54402;}s:5:"large";a:5:{s:4:"file";s:15:"8-1021x1024.png";s:5:"width";i:1021;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:512540;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"8-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16238;}s:12:"medium_large";a:5:{s:4:"file";s:13:"8-768x770.png";s:5:"width";i:768;s:6:"height";i:770;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:300769;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"8-1532x1536.png";s:5:"width";i:1532;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1078276;}s:9:"2048x2048";a:5:{s:4:"file";s:15:"8-2042x2048.png";s:5:"width";i:2042;s:6:"height";i:2048;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1777850;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(95, 40, '_wp_attached_file', '2022/10/9.png'),
(96, 40, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1541;s:6:"height";i:1451;s:4:"file";s:13:"2022/10/9.png";s:8:"filesize";i:1769739;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"9-300x282.png";s:5:"width";i:300;s:6:"height";i:282;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:106783;}s:5:"large";a:5:{s:4:"file";s:14:"9-1024x964.png";s:5:"width";i:1024;s:6:"height";i:964;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:849244;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"9-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37300;}s:12:"medium_large";a:5:{s:4:"file";s:13:"9-768x723.png";s:5:"width";i:768;s:6:"height";i:723;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:514957;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"9-1536x1446.png";s:5:"width";i:1536;s:6:"height";i:1446;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1618837;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(97, 41, '_wp_attached_file', '2022/10/10.png'),
(98, 41, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1286;s:6:"height";i:1520;s:4:"file";s:14:"2022/10/10.png";s:8:"filesize";i:1569049;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"10-254x300.png";s:5:"width";i:254;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:82584;}s:5:"large";a:5:{s:4:"file";s:15:"10-866x1024.png";s:5:"width";i:866;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:671214;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"10-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:33132;}s:12:"medium_large";a:5:{s:4:"file";s:14:"10-768x908.png";s:5:"width";i:768;s:6:"height";i:908;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:540189;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(99, 42, '_wp_attached_file', '2022/10/11.png'),
(100, 42, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1519;s:6:"height";i:1168;s:4:"file";s:14:"2022/10/11.png";s:8:"filesize";i:1367164;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"11-300x231.png";s:5:"width";i:300;s:6:"height";i:231;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66463;}s:5:"large";a:5:{s:4:"file";s:15:"11-1024x787.png";s:5:"width";i:1024;s:6:"height";i:787;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:556864;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"11-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:27744;}s:12:"medium_large";a:5:{s:4:"file";s:14:"11-768x591.png";s:5:"width";i:768;s:6:"height";i:591;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:327597;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(101, 43, '_wp_attached_file', '2022/10/12.png'),
(102, 43, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2131;s:6:"height";i:1868;s:4:"file";s:14:"2022/10/12.png";s:8:"filesize";i:2862443;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:14:"12-300x263.png";s:5:"width";i:300;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:73254;}s:5:"large";a:5:{s:4:"file";s:15:"12-1024x898.png";s:5:"width";i:1024;s:6:"height";i:898;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:615286;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"12-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28692;}s:12:"medium_large";a:5:{s:4:"file";s:14:"12-768x673.png";s:5:"width";i:768;s:6:"height";i:673;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:364515;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"12-1536x1346.png";s:5:"width";i:1536;s:6:"height";i:1346;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1321475;}s:9:"2048x2048";a:5:{s:4:"file";s:16:"12-2048x1795.png";s:5:"width";i:2048;s:6:"height";i:1795;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2292218;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(103, 44, '_wp_attached_file', '2022/10/13.png'),
(104, 44, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1469;s:6:"height";i:1587;s:4:"file";s:14:"2022/10/13.png";s:8:"filesize";i:1447618;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"13-278x300.png";s:5:"width";i:278;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:88856;}s:5:"large";a:5:{s:4:"file";s:15:"13-948x1024.png";s:5:"width";i:948;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:678506;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"13-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32862;}s:12:"medium_large";a:5:{s:4:"file";s:14:"13-768x830.png";s:5:"width";i:768;s:6:"height";i:830;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:474052;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"13-1422x1536.png";s:5:"width";i:1422;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1335914;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(105, 45, '_wp_attached_file', '2022/10/14.png'),
(106, 45, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1995;s:6:"height";i:1779;s:4:"file";s:14:"2022/10/14.png";s:8:"filesize";i:1951646;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"14-300x268.png";s:5:"width";i:300;s:6:"height";i:268;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:63997;}s:5:"large";a:5:{s:4:"file";s:15:"14-1024x913.png";s:5:"width";i:1024;s:6:"height";i:913;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:509807;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"14-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23948;}s:12:"medium_large";a:5:{s:4:"file";s:14:"14-768x685.png";s:5:"width";i:768;s:6:"height";i:685;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:308195;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"14-1536x1370.png";s:5:"width";i:1536;s:6:"height";i:1370;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1074505;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(107, 46, '_wp_attached_file', '2022/10/15.png'),
(108, 46, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2379;s:6:"height";i:1182;s:4:"file";s:14:"2022/10/15.png";s:8:"filesize";i:1872421;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:14:"15-300x149.png";s:5:"width";i:300;s:6:"height";i:149;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46571;}s:5:"large";a:5:{s:4:"file";s:15:"15-1024x509.png";s:5:"width";i:1024;s:6:"height";i:509;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:361646;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"15-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32677;}s:12:"medium_large";a:5:{s:4:"file";s:14:"15-768x382.png";s:5:"width";i:768;s:6:"height";i:382;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:220829;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"15-1536x763.png";s:5:"width";i:1536;s:6:"height";i:763;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:745615;}s:9:"2048x2048";a:5:{s:4:"file";s:16:"15-2048x1018.png";s:5:"width";i:2048;s:6:"height";i:1018;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1265115;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(109, 47, '_wp_attached_file', '2022/10/16.png'),
(110, 47, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1375;s:6:"height";i:1383;s:4:"file";s:14:"2022/10/16.png";s:8:"filesize";i:1208167;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"16-298x300.png";s:5:"width";i:298;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:79190;}s:5:"large";a:5:{s:4:"file";s:16:"16-1018x1024.png";s:5:"width";i:1018;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:666590;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"16-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:24443;}s:12:"medium_large";a:5:{s:4:"file";s:14:"16-768x772.png";s:5:"width";i:768;s:6:"height";i:772;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:410195;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(111, 48, '_wp_attached_file', '2022/10/17.png'),
(112, 48, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1561;s:6:"height";i:1527;s:4:"file";s:14:"2022/10/17.png";s:8:"filesize";i:2128286;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"17-300x293.png";s:5:"width";i:300;s:6:"height";i:293;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:95768;}s:5:"large";a:5:{s:4:"file";s:16:"17-1024x1002.png";s:5:"width";i:1024;s:6:"height";i:1002;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:919949;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"17-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30365;}s:12:"medium_large";a:5:{s:4:"file";s:14:"17-768x751.png";s:5:"width";i:768;s:6:"height";i:751;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:539907;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"17-1536x1503.png";s:5:"width";i:1536;s:6:"height";i:1503;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1866734;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(113, 49, '_wp_attached_file', '2022/10/18.png'),
(114, 49, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1764;s:6:"height";i:1546;s:4:"file";s:14:"2022/10/18.png";s:8:"filesize";i:2358996;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"18-300x263.png";s:5:"width";i:300;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:79574;}s:5:"large";a:5:{s:4:"file";s:15:"18-1024x897.png";s:5:"width";i:1024;s:6:"height";i:897;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:760487;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"18-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28780;}s:12:"medium_large";a:5:{s:4:"file";s:14:"18-768x673.png";s:5:"width";i:768;s:6:"height";i:673;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:446765;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"18-1536x1346.png";s:5:"width";i:1536;s:6:"height";i:1346;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1592206;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(115, 50, '_wp_attached_file', '2022/10/19.png'),
(116, 50, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1506;s:6:"height";i:1511;s:4:"file";s:14:"2022/10/19.png";s:8:"filesize";i:1827425;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"19-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:99118;}s:5:"large";a:5:{s:4:"file";s:16:"19-1021x1024.png";s:5:"width";i:1021;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:828837;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"19-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29846;}s:12:"medium_large";a:5:{s:4:"file";s:14:"19-768x771.png";s:5:"width";i:768;s:6:"height";i:771;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:506082;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(117, 51, '_wp_attached_file', '2022/10/20.png'),
(118, 51, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1481;s:6:"height";i:1192;s:4:"file";s:14:"2022/10/20.png";s:8:"filesize";i:2349739;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"20-300x241.png";s:5:"width";i:300;s:6:"height";i:241;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:110618;}s:5:"large";a:5:{s:4:"file";s:15:"20-1024x824.png";s:5:"width";i:1024;s:6:"height";i:824;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1087209;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"20-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41435;}s:12:"medium_large";a:5:{s:4:"file";s:14:"20-768x618.png";s:5:"width";i:768;s:6:"height";i:618;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:635301;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(119, 52, '_wp_attached_file', '2022/10/21.png'),
(120, 52, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1496;s:6:"height";i:1156;s:4:"file";s:14:"2022/10/21.png";s:8:"filesize";i:1779969;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"21-300x232.png";s:5:"width";i:300;s:6:"height";i:232;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:80991;}s:5:"large";a:5:{s:4:"file";s:15:"21-1024x791.png";s:5:"width";i:1024;s:6:"height";i:791;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:763919;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"21-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32437;}s:12:"medium_large";a:5:{s:4:"file";s:14:"21-768x593.png";s:5:"width";i:768;s:6:"height";i:593;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:445664;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(121, 53, '_wp_attached_file', '2022/10/22.png'),
(122, 53, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1554;s:6:"height";i:1361;s:4:"file";s:14:"2022/10/22.png";s:8:"filesize";i:2197778;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"22-300x263.png";s:5:"width";i:300;s:6:"height";i:263;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:104268;}s:5:"large";a:5:{s:4:"file";s:15:"22-1024x897.png";s:5:"width";i:1024;s:6:"height";i:897;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:903258;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"22-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37577;}s:12:"medium_large";a:5:{s:4:"file";s:14:"22-768x673.png";s:5:"width";i:768;s:6:"height";i:673;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:538881;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"22-1536x1345.png";s:5:"width";i:1536;s:6:"height";i:1345;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1863951;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(123, 54, '_wp_attached_file', '2022/10/23.png'),
(124, 54, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1588;s:6:"height";i:1479;s:4:"file";s:14:"2022/10/23.png";s:8:"filesize";i:1849092;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"23-300x279.png";s:5:"width";i:300;s:6:"height";i:279;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:73178;}s:5:"large";a:5:{s:4:"file";s:15:"23-1024x954.png";s:5:"width";i:1024;s:6:"height";i:954;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:682174;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"23-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25134;}s:12:"medium_large";a:5:{s:4:"file";s:14:"23-768x715.png";s:5:"width";i:768;s:6:"height";i:715;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:398555;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"23-1536x1431.png";s:5:"width";i:1536;s:6:"height";i:1431;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1459354;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(125, 55, '_wp_attached_file', '2022/10/24.png'),
(126, 55, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1413;s:6:"height";i:1328;s:4:"file";s:14:"2022/10/24.png";s:8:"filesize";i:1568562;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"24-300x282.png";s:5:"width";i:300;s:6:"height";i:282;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:88750;}s:5:"large";a:5:{s:4:"file";s:15:"24-1024x962.png";s:5:"width";i:1024;s:6:"height";i:962;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:797261;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"24-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29423;}s:12:"medium_large";a:5:{s:4:"file";s:14:"24-768x722.png";s:5:"width";i:768;s:6:"height";i:722;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:477196;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(127, 56, '_wp_attached_file', '2022/10/25.png'),
(128, 56, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1391;s:6:"height";i:1312;s:4:"file";s:14:"2022/10/25.png";s:8:"filesize";i:2190273;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"25-300x283.png";s:5:"width";i:300;s:6:"height";i:283;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:106502;}s:5:"large";a:5:{s:4:"file";s:15:"25-1024x966.png";s:5:"width";i:1024;s:6:"height";i:966;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1093922;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"25-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:33134;}s:12:"medium_large";a:5:{s:4:"file";s:14:"25-768x724.png";s:5:"width";i:768;s:6:"height";i:724;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:630451;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(129, 57, '_wp_attached_file', '2022/10/26.png'),
(130, 57, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1383;s:6:"height";i:1204;s:4:"file";s:14:"2022/10/26.png";s:8:"filesize";i:1885902;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"26-300x261.png";s:5:"width";i:300;s:6:"height";i:261;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:102988;}s:5:"large";a:5:{s:4:"file";s:15:"26-1024x891.png";s:5:"width";i:1024;s:6:"height";i:891;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:970441;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"26-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35749;}s:12:"medium_large";a:5:{s:4:"file";s:14:"26-768x669.png";s:5:"width";i:768;s:6:"height";i:669;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:577992;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(131, 58, '_wp_attached_file', '2022/10/27.png'),
(132, 58, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1694;s:6:"height";i:1538;s:4:"file";s:14:"2022/10/27.png";s:8:"filesize";i:2059168;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"27-300x272.png";s:5:"width";i:300;s:6:"height";i:272;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74909;}s:5:"large";a:5:{s:4:"file";s:15:"27-1024x930.png";s:5:"width";i:1024;s:6:"height";i:930;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:731057;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"27-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25966;}s:12:"medium_large";a:5:{s:4:"file";s:14:"27-768x697.png";s:5:"width";i:768;s:6:"height";i:697;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:425491;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"27-1536x1395.png";s:5:"width";i:1536;s:6:"height";i:1395;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1529185;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(133, 59, '_wp_attached_file', '2022/10/28.png'),
(134, 59, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1419;s:6:"height";i:1451;s:4:"file";s:14:"2022/10/28.png";s:8:"filesize";i:2010789;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:14:"28-293x300.png";s:5:"width";i:293;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:103247;}s:5:"large";a:5:{s:4:"file";s:16:"28-1001x1024.png";s:5:"width";i:1001;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:979259;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"28-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30841;}s:12:"medium_large";a:5:{s:4:"file";s:14:"28-768x785.png";s:5:"width";i:768;s:6:"height";i:785;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:606623;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(135, 60, '_wp_attached_file', '2022/10/29.png'),
(136, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1793;s:6:"height";i:1842;s:4:"file";s:14:"2022/10/29.png";s:8:"filesize";i:2277517;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"29-292x300.png";s:5:"width";i:292;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71896;}s:5:"large";a:5:{s:4:"file";s:15:"29-997x1024.png";s:5:"width";i:997;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:697732;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"29-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21642;}s:12:"medium_large";a:5:{s:4:"file";s:14:"29-768x789.png";s:5:"width";i:768;s:6:"height";i:789;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:430265;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"29-1495x1536.png";s:5:"width";i:1495;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1456804;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(137, 61, '_wp_attached_file', '2022/10/30.png'),
(138, 61, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1523;s:6:"height";i:1574;s:4:"file";s:14:"2022/10/30.png";s:8:"filesize";i:2417547;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:14:"30-290x300.png";s:5:"width";i:290;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:100745;}s:5:"large";a:5:{s:4:"file";s:15:"30-991x1024.png";s:5:"width";i:991;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:993164;}s:9:"thumbnail";a:5:{s:4:"file";s:14:"30-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30359;}s:12:"medium_large";a:5:{s:4:"file";s:14:"30-768x794.png";s:5:"width";i:768;s:6:"height";i:794;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:619851;}s:9:"1536x1536";a:5:{s:4:"file";s:16:"30-1486x1536.png";s:5:"width";i:1486;s:6:"height";i:1536;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2048455;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(139, 62, '_wp_attached_file', '2022/10/Lindo-catalog-NEW-2.png'),
(140, 62, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1357;s:6:"height";i:1266;s:4:"file";s:31:"2022/10/Lindo-catalog-NEW-2.png";s:8:"filesize";i:2148557;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:31:"Lindo-catalog-NEW-2-300x280.png";s:5:"width";i:300;s:6:"height";i:280;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:101291;}s:5:"large";a:5:{s:4:"file";s:32:"Lindo-catalog-NEW-2-1024x955.png";s:5:"width";i:1024;s:6:"height";i:955;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1048091;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"Lindo-catalog-NEW-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32251;}s:12:"medium_large";a:5:{s:4:"file";s:31:"Lindo-catalog-NEW-2-768x716.png";s:5:"width";i:768;s:6:"height";i:716;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:598420;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(141, 63, '_wp_attached_file', '2022/10/1.png'),
(142, 63, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:3024;s:6:"height";i:2173;s:4:"file";s:13:"2022/10/1.png";s:8:"filesize";i:1988343;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:13:"1-300x216.png";s:5:"width";i:300;s:6:"height";i:216;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36114;}s:5:"large";a:5:{s:4:"file";s:14:"1-1024x736.png";s:5:"width";i:1024;s:6:"height";i:736;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:297043;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19247;}s:12:"medium_large";a:5:{s:4:"file";s:13:"1-768x552.png";s:5:"width";i:768;s:6:"height";i:552;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:180963;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"1-1536x1104.png";s:5:"width";i:1536;s:6:"height";i:1104;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:598804;}s:9:"2048x2048";a:5:{s:4:"file";s:15:"1-2048x1472.png";s:5:"width";i:2048;s:6:"height";i:1472;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:989753;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(143, 64, '_wp_attached_file', '2022/10/2.png'),
(144, 64, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1936;s:6:"height";i:1578;s:4:"file";s:13:"2022/10/2.png";s:8:"filesize";i:2114220;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:13:"2-300x245.png";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:69923;}s:5:"large";a:5:{s:4:"file";s:14:"2-1024x835.png";s:5:"width";i:1024;s:6:"height";i:835;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:588472;}s:9:"thumbnail";a:5:{s:4:"file";s:13:"2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29987;}s:12:"medium_large";a:5:{s:4:"file";s:13:"2-768x626.png";s:5:"width";i:768;s:6:"height";i:626;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:351067;}s:9:"1536x1536";a:5:{s:4:"file";s:15:"2-1536x1252.png";s:5:"width";i:1536;s:6:"height";i:1252;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1242236;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(145, 65, '_edit_lock', '1666208724:1'),
(150, 65, '_wp_page_template', 'pageArticle.php'),
(151, 65, '_edit_last', '1'),
(152, 65, 'first_img', '63'),
(153, 65, '_first_img', 'field_63430061a648c'),
(154, 65, 'name_product', 'Florentis'),
(155, 65, '_name_product', 'field_634300b2a648d'),
(156, 65, 'product_com', ''),
(157, 65, '_product_com', 'field_63430156a648f'),
(158, 67, 'first_img', '63'),
(159, 67, '_first_img', 'field_63430061a648c'),
(160, 67, 'name_product', 'Florentis'),
(161, 67, '_name_product', 'field_634300b2a648d'),
(162, 67, 'product_com', ''),
(163, 67, '_product_com', 'field_63430156a648f'),
(164, 68, '_edit_lock', '1666208823:1'),
(167, 68, '_wp_page_template', 'pageArticle.php'),
(168, 68, '_edit_last', '1'),
(169, 68, 'first_img', '64'),
(170, 68, '_first_img', 'field_63430061a648c'),
(171, 68, 'name_product', 'Benicia'),
(172, 68, '_name_product', 'field_634300b2a648d'),
(173, 68, 'product_com', ''),
(174, 68, '_product_com', 'field_63430156a648f'),
(175, 70, 'first_img', '64'),
(176, 70, '_first_img', 'field_63430061a648c'),
(177, 70, 'name_product', 'Benicia'),
(178, 70, '_name_product', 'field_634300b2a648d'),
(179, 70, 'product_com', ''),
(180, 70, '_product_com', 'field_63430156a648f'),
(181, 71, '_edit_lock', '1666208938:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(184, 71, '_wp_page_template', 'pageArticle.php'),
(185, 71, '_edit_last', '1'),
(186, 71, 'first_img', '34'),
(187, 71, '_first_img', 'field_63430061a648c'),
(188, 71, 'name_product', 'Victoria'),
(189, 71, '_name_product', 'field_634300b2a648d'),
(190, 71, 'product_com', ''),
(191, 71, '_product_com', 'field_63430156a648f'),
(192, 73, 'first_img', '34'),
(193, 73, '_first_img', 'field_63430061a648c'),
(194, 73, 'name_product', 'Victoria'),
(195, 73, '_name_product', 'field_634300b2a648d'),
(196, 73, 'product_com', ''),
(197, 73, '_product_com', 'field_63430156a648f'),
(198, 74, '_edit_lock', '1666209003:1'),
(201, 74, '_wp_page_template', 'pageArticle.php'),
(202, 74, '_edit_last', '1'),
(203, 74, 'first_img', '36'),
(204, 74, '_first_img', 'field_63430061a648c'),
(205, 74, 'name_product', 'Muhtasem'),
(206, 74, '_name_product', 'field_634300b2a648d'),
(207, 74, 'product_com', ''),
(208, 74, '_product_com', 'field_63430156a648f'),
(209, 76, 'first_img', '36'),
(210, 76, '_first_img', 'field_63430061a648c'),
(211, 76, 'name_product', 'Muhtasem'),
(212, 76, '_name_product', 'field_634300b2a648d'),
(213, 76, 'product_com', ''),
(214, 76, '_product_com', 'field_63430156a648f'),
(215, 77, '_edit_lock', '1666209067:1'),
(218, 77, '_wp_page_template', 'pageArticle.php'),
(219, 77, '_edit_last', '1'),
(220, 77, 'first_img', '37'),
(221, 77, '_first_img', 'field_63430061a648c'),
(222, 77, 'name_product', 'Levante'),
(223, 77, '_name_product', 'field_634300b2a648d'),
(224, 77, 'product_com', ''),
(225, 77, '_product_com', 'field_63430156a648f'),
(226, 79, 'first_img', '37'),
(227, 79, '_first_img', 'field_63430061a648c'),
(228, 79, 'name_product', 'Levante'),
(229, 79, '_name_product', 'field_634300b2a648d'),
(230, 79, 'product_com', ''),
(231, 79, '_product_com', 'field_63430156a648f'),
(232, 80, '_edit_lock', '1666209119:1'),
(235, 80, '_wp_page_template', 'pageArticle.php'),
(236, 80, '_edit_last', '1'),
(237, 82, '_edit_lock', '1666209186:1'),
(238, 80, 'first_img', '38'),
(239, 80, '_first_img', 'field_63430061a648c'),
(240, 80, 'name_product', 'President'),
(241, 80, '_name_product', 'field_634300b2a648d'),
(242, 80, 'product_com', ''),
(243, 80, '_product_com', 'field_63430156a648f'),
(244, 83, 'first_img', '38'),
(245, 83, '_first_img', 'field_63430061a648c'),
(246, 83, 'name_product', 'President'),
(247, 83, '_name_product', 'field_634300b2a648d'),
(248, 83, 'product_com', ''),
(249, 83, '_product_com', 'field_63430156a648f'),
(252, 82, '_wp_page_template', 'pageArticle.php'),
(253, 82, '_edit_last', '1'),
(254, 82, 'first_img', '39'),
(255, 82, '_first_img', 'field_63430061a648c'),
(256, 82, 'name_product', 'Sweet&Milk'),
(257, 82, '_name_product', 'field_634300b2a648d'),
(258, 82, 'product_com', ''),
(259, 82, '_product_com', 'field_63430156a648f'),
(260, 85, 'first_img', '39'),
(261, 85, '_first_img', 'field_63430061a648c'),
(262, 85, 'name_product', 'Sweet&Milk'),
(263, 85, '_name_product', 'field_634300b2a648d'),
(264, 85, 'product_com', ''),
(265, 85, '_product_com', 'field_63430156a648f'),
(266, 86, '_edit_lock', '1666209286:1'),
(269, 86, '_wp_page_template', 'pageArticle.php'),
(270, 86, '_edit_last', '1'),
(271, 86, 'first_img', '41'),
(272, 86, '_first_img', 'field_63430061a648c'),
(273, 86, 'name_product', 'Milano'),
(274, 86, '_name_product', 'field_634300b2a648d'),
(275, 86, 'product_com', ''),
(276, 86, '_product_com', 'field_63430156a648f'),
(277, 88, 'first_img', '41'),
(278, 88, '_first_img', 'field_63430061a648c'),
(279, 88, 'name_product', 'Milano'),
(280, 88, '_name_product', 'field_634300b2a648d'),
(281, 88, 'product_com', ''),
(282, 88, '_product_com', 'field_63430156a648f'),
(283, 89, '_edit_lock', '1666209354:1'),
(286, 89, '_wp_page_template', 'pageArticle.php'),
(287, 89, '_edit_last', '1'),
(288, 89, 'first_img', '42'),
(289, 89, '_first_img', 'field_63430061a648c'),
(290, 89, 'name_product', 'Milano'),
(291, 89, '_name_product', 'field_634300b2a648d'),
(292, 89, 'product_com', ''),
(293, 89, '_product_com', 'field_63430156a648f'),
(294, 91, 'first_img', '42'),
(295, 91, '_first_img', 'field_63430061a648c') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(296, 91, 'name_product', 'Milano'),
(297, 91, '_name_product', 'field_634300b2a648d'),
(298, 91, 'product_com', ''),
(299, 91, '_product_com', 'field_63430156a648f'),
(300, 92, '_edit_lock', '1666209394:1'),
(303, 92, '_wp_page_template', 'pageArticle.php'),
(304, 92, '_edit_last', '1'),
(305, 92, 'first_img', '40'),
(306, 92, '_first_img', 'field_63430061a648c'),
(307, 92, 'name_product', 'Florentis'),
(308, 92, '_name_product', 'field_634300b2a648d'),
(309, 92, 'product_com', ''),
(310, 92, '_product_com', 'field_63430156a648f'),
(311, 94, 'first_img', '40'),
(312, 94, '_first_img', 'field_63430061a648c'),
(313, 94, 'name_product', 'Florentis'),
(314, 94, '_name_product', 'field_634300b2a648d'),
(315, 94, 'product_com', ''),
(316, 94, '_product_com', 'field_63430156a648f'),
(317, 95, '_edit_lock', '1666209492:1'),
(320, 95, '_wp_page_template', 'pageArticle.php'),
(321, 95, '_edit_last', '1'),
(322, 95, 'first_img', '43'),
(323, 95, '_first_img', 'field_63430061a648c'),
(324, 95, 'name_product', '360°'),
(325, 95, '_name_product', 'field_634300b2a648d'),
(326, 95, 'product_com', ''),
(327, 95, '_product_com', 'field_63430156a648f'),
(328, 97, 'first_img', '43'),
(329, 97, '_first_img', 'field_63430061a648c'),
(330, 97, 'name_product', '360°'),
(331, 97, '_name_product', 'field_634300b2a648d'),
(332, 97, 'product_com', ''),
(333, 97, '_product_com', 'field_63430156a648f'),
(334, 98, '_edit_lock', '1666209536:1'),
(337, 98, '_wp_page_template', 'pageArticle.php'),
(338, 98, '_edit_last', '1'),
(339, 98, 'first_img', '44'),
(340, 98, '_first_img', 'field_63430061a648c'),
(341, 98, 'name_product', 'Delice'),
(342, 98, '_name_product', 'field_634300b2a648d'),
(343, 98, 'product_com', ''),
(344, 98, '_product_com', 'field_63430156a648f'),
(345, 100, 'first_img', '44'),
(346, 100, '_first_img', 'field_63430061a648c'),
(347, 100, 'name_product', 'Delice'),
(348, 100, '_name_product', 'field_634300b2a648d'),
(349, 100, 'product_com', ''),
(350, 100, '_product_com', 'field_63430156a648f'),
(351, 101, '_edit_lock', '1666209575:1'),
(354, 101, '_wp_page_template', 'pageArticle.php'),
(355, 101, '_edit_last', '1'),
(356, 101, 'first_img', '45'),
(357, 101, '_first_img', 'field_63430061a648c'),
(358, 101, 'name_product', 'Compete'),
(359, 101, '_name_product', 'field_634300b2a648d'),
(360, 101, 'product_com', ''),
(361, 101, '_product_com', 'field_63430156a648f'),
(362, 103, 'first_img', '45'),
(363, 103, '_first_img', 'field_63430061a648c'),
(364, 103, 'name_product', 'Compete'),
(365, 103, '_name_product', 'field_634300b2a648d'),
(366, 103, 'product_com', ''),
(367, 103, '_product_com', 'field_63430156a648f'),
(368, 104, '_edit_lock', '1666209616:1'),
(371, 104, '_wp_page_template', 'pageArticle.php'),
(372, 104, '_edit_last', '1'),
(373, 107, '_edit_lock', '1666209683:1'),
(374, 104, 'first_img', '46'),
(375, 104, '_first_img', 'field_63430061a648c'),
(376, 104, 'name_product', 'Chocolay'),
(377, 104, '_name_product', 'field_634300b2a648d'),
(378, 104, 'product_com', ''),
(379, 104, '_product_com', 'field_63430156a648f'),
(380, 106, 'first_img', '46'),
(381, 106, '_first_img', 'field_63430061a648c'),
(382, 106, 'name_product', 'Chocolay'),
(383, 106, '_name_product', 'field_634300b2a648d'),
(384, 106, 'product_com', ''),
(385, 106, '_product_com', 'field_63430156a648f'),
(388, 107, '_wp_page_template', 'pageArticle.php'),
(389, 107, '_edit_last', '1'),
(390, 107, 'first_img', '47'),
(391, 107, '_first_img', 'field_63430061a648c'),
(392, 107, 'name_product', '360° kg'),
(393, 107, '_name_product', 'field_634300b2a648d'),
(394, 107, 'product_com', ''),
(395, 107, '_product_com', 'field_63430156a648f'),
(396, 109, 'first_img', '47'),
(397, 109, '_first_img', 'field_63430061a648c'),
(398, 109, 'name_product', '360° kg'),
(399, 109, '_name_product', 'field_634300b2a648d'),
(400, 109, 'product_com', ''),
(401, 109, '_product_com', 'field_63430156a648f'),
(402, 110, '_edit_lock', '1666209749:1'),
(405, 110, '_wp_page_template', 'pageArticle.php'),
(406, 110, '_edit_last', '1'),
(407, 110, 'first_img', '48'),
(408, 110, '_first_img', 'field_63430061a648c'),
(409, 110, 'name_product', 'Палочка') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(410, 110, '_name_product', 'field_634300b2a648d'),
(411, 110, 'product_com', ''),
(412, 110, '_product_com', 'field_63430156a648f'),
(413, 112, 'first_img', '48'),
(414, 112, '_first_img', 'field_63430061a648c'),
(415, 112, 'name_product', 'Палочка'),
(416, 112, '_name_product', 'field_634300b2a648d'),
(417, 112, 'product_com', ''),
(418, 112, '_product_com', 'field_63430156a648f'),
(419, 113, '_edit_lock', '1666209811:1'),
(422, 113, '_wp_page_template', 'pageArticle.php'),
(423, 113, '_edit_last', '1'),
(424, 113, 'first_img', '49'),
(425, 113, '_first_img', 'field_63430061a648c'),
(426, 113, 'name_product', 'Hi-Tech'),
(427, 113, '_name_product', 'field_634300b2a648d'),
(428, 113, 'product_com', ''),
(429, 113, '_product_com', 'field_63430156a648f'),
(430, 115, 'first_img', '49'),
(431, 115, '_first_img', 'field_63430061a648c'),
(432, 115, 'name_product', 'Hi-Tech'),
(433, 115, '_name_product', 'field_634300b2a648d'),
(434, 115, 'product_com', ''),
(435, 115, '_product_com', 'field_63430156a648f'),
(436, 116, '_edit_lock', '1666209846:1'),
(439, 116, '_wp_page_template', 'pageArticle.php'),
(440, 116, '_edit_last', '1'),
(441, 116, 'first_img', '50'),
(442, 116, '_first_img', 'field_63430061a648c'),
(443, 116, 'name_product', 'Cappuccino '),
(444, 116, '_name_product', 'field_634300b2a648d'),
(445, 116, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(446, 116, '_product_com', 'field_63430156a648f'),
(447, 118, 'first_img', '50'),
(448, 118, '_first_img', 'field_63430061a648c'),
(449, 118, 'name_product', 'Cappuccino '),
(450, 118, '_name_product', 'field_634300b2a648d'),
(451, 118, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(452, 118, '_product_com', 'field_63430156a648f'),
(453, 119, '_edit_lock', '1666209888:1'),
(456, 119, '_wp_page_template', 'pageArticle.php'),
(457, 119, '_edit_last', '1'),
(458, 119, 'first_img', '51'),
(459, 119, '_first_img', 'field_63430061a648c'),
(460, 119, 'name_product', 'LOCHIRA '),
(461, 119, '_name_product', 'field_634300b2a648d'),
(462, 119, 'product_com', ''),
(463, 119, '_product_com', 'field_63430156a648f'),
(464, 121, 'first_img', '51'),
(465, 121, '_first_img', 'field_63430061a648c'),
(466, 121, 'name_product', 'LOCHIRA '),
(467, 121, '_name_product', 'field_634300b2a648d'),
(468, 121, 'product_com', ''),
(469, 121, '_product_com', 'field_63430156a648f'),
(470, 122, '_edit_lock', '1666209954:1'),
(473, 122, '_wp_page_template', 'pageArticle.php'),
(474, 122, '_edit_last', '1'),
(475, 122, 'first_img', '52'),
(476, 122, '_first_img', 'field_63430061a648c'),
(477, 122, 'name_product', 'LOCHIRA '),
(478, 122, '_name_product', 'field_634300b2a648d'),
(479, 122, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(480, 122, '_product_com', 'field_63430156a648f'),
(481, 124, 'first_img', '52'),
(482, 124, '_first_img', 'field_63430061a648c'),
(483, 124, 'name_product', 'LOCHIRA '),
(484, 124, '_name_product', 'field_634300b2a648d'),
(485, 124, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(486, 124, '_product_com', 'field_63430156a648f'),
(487, 125, '_edit_lock', '1666210018:1'),
(490, 125, '_wp_page_template', 'pageArticle.php'),
(491, 125, '_edit_last', '1'),
(492, 125, 'first_img', '53'),
(493, 125, '_first_img', 'field_63430061a648c'),
(494, 125, 'name_product', 'KUNJUTLI '),
(495, 125, '_name_product', 'field_634300b2a648d'),
(496, 125, 'product_com', ''),
(497, 125, '_product_com', 'field_63430156a648f'),
(498, 127, 'first_img', '53'),
(499, 127, '_first_img', 'field_63430061a648c'),
(500, 127, 'name_product', 'KUNJUTLI '),
(501, 127, '_name_product', 'field_634300b2a648d'),
(502, 127, 'product_com', ''),
(503, 127, '_product_com', 'field_63430156a648f'),
(504, 128, '_edit_lock', '1666210048:1'),
(507, 128, '_wp_page_template', 'pageArticle.php'),
(508, 128, '_edit_last', '1'),
(509, 128, 'first_img', '54'),
(510, 128, '_first_img', 'field_63430061a648c'),
(511, 128, 'name_product', 'Cappuccino '),
(512, 128, '_name_product', 'field_634300b2a648d'),
(513, 128, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(514, 128, '_product_com', 'field_63430156a648f'),
(515, 130, 'first_img', '54'),
(516, 130, '_first_img', 'field_63430061a648c'),
(517, 130, 'name_product', 'Cappuccino '),
(518, 130, '_name_product', 'field_634300b2a648d'),
(519, 130, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(520, 130, '_product_com', 'field_63430156a648f'),
(521, 131, '_edit_lock', '1666210086:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(524, 131, '_wp_page_template', 'pageArticle.php'),
(525, 131, '_edit_last', '1'),
(526, 131, 'first_img', '55'),
(527, 131, '_first_img', 'field_63430061a648c'),
(528, 131, 'name_product', 'LINDO '),
(529, 131, '_name_product', 'field_634300b2a648d'),
(530, 131, 'product_com', ''),
(531, 131, '_product_com', 'field_63430156a648f'),
(532, 133, 'first_img', '55'),
(533, 133, '_first_img', 'field_63430061a648c'),
(534, 133, 'name_product', 'LINDO '),
(535, 133, '_name_product', 'field_634300b2a648d'),
(536, 133, 'product_com', ''),
(537, 133, '_product_com', 'field_63430156a648f'),
(538, 134, '_edit_lock', '1666210147:1'),
(541, 134, '_wp_page_template', 'pageArticle.php'),
(542, 134, '_edit_last', '1'),
(543, 134, 'first_img', '56'),
(544, 134, '_first_img', 'field_63430061a648c'),
(545, 134, 'name_product', 'LINDO '),
(546, 134, '_name_product', 'field_634300b2a648d'),
(547, 134, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(548, 134, '_product_com', 'field_63430156a648f'),
(549, 136, 'first_img', '56'),
(550, 136, '_first_img', 'field_63430061a648c'),
(551, 136, 'name_product', 'LINDO '),
(552, 136, '_name_product', 'field_634300b2a648d'),
(553, 136, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(554, 136, '_product_com', 'field_63430156a648f'),
(555, 137, '_edit_lock', '1666210234:1'),
(558, 137, '_wp_page_template', 'pageArticle.php'),
(559, 137, '_edit_last', '1'),
(560, 137, 'first_img', '58'),
(561, 137, '_first_img', 'field_63430061a648c'),
(562, 137, 'name_product', 'HI-TECH'),
(563, 137, '_name_product', 'field_634300b2a648d'),
(564, 137, 'product_com', ''),
(565, 137, '_product_com', 'field_63430156a648f'),
(566, 139, 'first_img', '58'),
(567, 139, '_first_img', 'field_63430061a648c'),
(568, 139, 'name_product', 'HI-TECH'),
(569, 139, '_name_product', 'field_634300b2a648d'),
(570, 139, 'product_com', ''),
(571, 139, '_product_com', 'field_63430156a648f'),
(572, 140, '_edit_lock', '1666210265:1'),
(575, 140, '_wp_page_template', 'pageArticle.php'),
(576, 140, '_edit_last', '1'),
(577, 140, 'first_img', '57'),
(578, 140, '_first_img', 'field_63430061a648c'),
(579, 140, 'name_product', 'HI-TECH'),
(580, 140, '_name_product', 'field_634300b2a648d'),
(581, 140, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(582, 140, '_product_com', 'field_63430156a648f'),
(583, 142, 'first_img', '57'),
(584, 142, '_first_img', 'field_63430061a648c'),
(585, 142, 'name_product', 'HI-TECH'),
(586, 142, '_name_product', 'field_634300b2a648d'),
(587, 142, 'product_com', 'Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun'),
(588, 142, '_product_com', 'field_63430156a648f'),
(589, 143, '_edit_lock', '1666210301:1'),
(592, 143, '_wp_page_template', 'pageArticle.php'),
(593, 143, '_edit_last', '1'),
(594, 145, '_edit_lock', '1666210340:1'),
(595, 143, 'first_img', '60'),
(596, 143, '_first_img', 'field_63430061a648c'),
(597, 143, 'name_product', 'КОРОВКА'),
(598, 143, '_name_product', 'field_634300b2a648d'),
(599, 143, 'product_com', ''),
(600, 143, '_product_com', 'field_63430156a648f'),
(601, 146, 'first_img', '60'),
(602, 146, '_first_img', 'field_63430061a648c'),
(603, 146, 'name_product', 'КОРОВКА'),
(604, 146, '_name_product', 'field_634300b2a648d'),
(605, 146, 'product_com', ''),
(606, 146, '_product_com', 'field_63430156a648f'),
(609, 145, '_wp_page_template', 'pageArticle.php'),
(610, 145, '_edit_last', '1'),
(611, 145, 'first_img', '59'),
(612, 145, '_first_img', 'field_63430061a648c'),
(613, 145, 'name_product', 'ЮБИЛЕЙНОЕ'),
(614, 145, '_name_product', 'field_634300b2a648d'),
(615, 145, 'product_com', ''),
(616, 145, '_product_com', 'field_63430156a648f'),
(617, 148, 'first_img', '59'),
(618, 148, '_first_img', 'field_63430061a648c'),
(619, 148, 'name_product', 'ЮБИЛЕЙНОЕ'),
(620, 148, '_name_product', 'field_634300b2a648d'),
(621, 148, 'product_com', ''),
(622, 148, '_product_com', 'field_63430156a648f'),
(623, 149, '_edit_lock', '1666210415:1'),
(626, 149, '_wp_page_template', 'pageArticle.php'),
(627, 149, '_edit_last', '1'),
(628, 149, 'first_img', '61'),
(629, 149, '_first_img', 'field_63430061a648c'),
(630, 149, 'name_product', 'Топленое'),
(631, 149, '_name_product', 'field_634300b2a648d'),
(632, 149, 'product_com', ''),
(633, 149, '_product_com', 'field_63430156a648f'),
(634, 151, 'first_img', '61'),
(635, 151, '_first_img', 'field_63430061a648c') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(636, 151, 'name_product', 'Топленое'),
(637, 151, '_name_product', 'field_634300b2a648d'),
(638, 151, 'product_com', ''),
(639, 151, '_product_com', 'field_63430156a648f'),
(640, 152, '_edit_lock', '1666212857:1'),
(643, 152, '_wp_page_template', 'pageArticle.php'),
(644, 152, '_edit_last', '1'),
(645, 152, 'first_img', '62'),
(646, 152, '_first_img', 'field_63430061a648c'),
(647, 152, 'name_product', 'Coffee'),
(648, 152, '_name_product', 'field_634300b2a648d'),
(649, 152, 'product_com', ''),
(650, 152, '_product_com', 'field_63430156a648f'),
(651, 154, 'first_img', '62'),
(652, 154, '_first_img', 'field_63430061a648c'),
(653, 154, 'name_product', 'Coffee'),
(654, 154, '_name_product', 'field_634300b2a648d'),
(655, 154, 'product_com', ''),
(656, 154, '_product_com', 'field_63430156a648f') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(7, 1, '2022-09-28 21:29:07', '2022-09-28 18:29:07', '', 'lindo', '', 'publish', 'closed', 'closed', '', 'lindo', '', '', '2022-09-28 21:29:07', '2022-09-28 18:29:07', '', 0, 'http://lindo/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-09-28 21:28:17', '2022-09-28 18:28:17', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-lindo', '', '', '2022-09-28 21:28:17', '2022-09-28 18:28:17', '', 0, 'http://lindo/2022/09/28/wp-global-styles-lindo/', 0, 'wp_global_styles', '', 0),
(9, 1, '2022-09-28 21:29:07', '2022-09-28 18:29:07', '', 'lindo', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-09-28 21:29:07', '2022-09-28 18:29:07', '', 7, 'http://lindo/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-09-28 21:31:08', '2022-09-28 18:31:08', '', 'allProducts', '', 'publish', 'closed', 'closed', '', 'allproducts', '', '', '2022-09-28 21:31:08', '2022-09-28 18:31:08', '', 0, 'http://lindo/?page_id=10', 0, 'page', '', 0),
(11, 1, '2022-09-28 21:31:08', '2022-09-28 18:31:08', '', 'allProducts', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-09-28 21:31:08', '2022-09-28 18:31:08', '', 10, 'http://lindo/?p=11', 0, 'revision', '', 0),
(15, 1, '2022-10-09 20:22:48', '2022-10-09 17:22:48', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'lindo Products', 'lindo-products', 'publish', 'closed', 'closed', '', 'group_634300607d8d0', '', '', '2022-10-19 22:35:18', '2022-10-19 19:35:18', '', 0, 'http://lindo/?post_type=acf-field-group&#038;p=15', 0, 'acf-field-group', '', 0),
(16, 1, '2022-10-09 20:22:48', '2022-10-09 17:22:48', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:4:"full";}', 'First Img', 'first_img', 'publish', 'closed', 'closed', '', 'field_63430061a648c', '', '', '2022-10-09 20:22:48', '2022-10-09 17:22:48', '', 15, 'http://lindo/?post_type=acf-field&p=16', 0, 'acf-field', '', 0),
(19, 1, '2022-10-09 20:22:48', '2022-10-09 17:22:48', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:29:"Botga Praductni nomi yoziladi";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'name product', 'name_product', 'publish', 'closed', 'closed', '', 'field_634300b2a648d', '', '', '2022-10-19 22:35:17', '2022-10-19 19:35:17', '', 15, 'http://lindo/?post_type=acf-field&#038;p=19', 1, 'acf-field', '', 0),
(20, 1, '2022-10-09 20:22:48', '2022-10-09 17:22:48', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:102:"Productni sostavi yoziladigan joy tepadigi knopkala orqali edit qilishili yoki create qilishila mumkun";s:5:"delay";i:0;s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'composition of the product', 'product_com', 'publish', 'closed', 'closed', '', 'field_63430156a648f', '', '', '2022-10-19 22:35:17', '2022-10-19 19:35:17', '', 15, 'http://lindo/?post_type=acf-field&#038;p=20', 2, 'acf-field', '', 0),
(29, 1, '2022-10-09 21:04:00', '2022-10-09 18:04:00', '', 'Article', '', 'publish', 'closed', 'closed', '', 'article', '', '', '2022-10-09 21:04:00', '2022-10-09 18:04:00', '', 0, 'http://lindo/?page_id=29', 0, 'page', '', 0),
(30, 1, '2022-10-09 21:04:00', '2022-10-09 18:04:00', '', 'Article', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2022-10-09 21:04:00', '2022-10-09 18:04:00', '', 29, 'http://lindo/?p=30', 0, 'revision', '', 0),
(34, 1, '2022-10-19 22:37:19', '2022-10-19 19:37:19', '', '3', '', 'inherit', 'open', 'closed', '', '3', '', '', '2022-10-19 22:48:54', '2022-10-19 19:48:54', '', 71, 'http://lindo/wp-content/uploads/2022/10/3.png', 0, 'attachment', 'image/png', 0),
(35, 1, '2022-10-19 22:37:31', '2022-10-19 19:37:31', '', '4', '', 'inherit', 'open', 'closed', '', '4', '', '', '2022-10-19 22:37:31', '2022-10-19 19:37:31', '', 0, 'http://lindo/wp-content/uploads/2022/10/4.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2022-10-19 22:37:36', '2022-10-19 19:37:36', '', '5', '', 'inherit', 'open', 'closed', '', '5', '', '', '2022-10-19 22:50:01', '2022-10-19 19:50:01', '', 74, 'http://lindo/wp-content/uploads/2022/10/5.png', 0, 'attachment', 'image/png', 0),
(37, 1, '2022-10-19 22:37:43', '2022-10-19 19:37:43', '', '6', '', 'inherit', 'open', 'closed', '', '6', '', '', '2022-10-19 22:51:04', '2022-10-19 19:51:04', '', 77, 'http://lindo/wp-content/uploads/2022/10/6.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2022-10-19 22:37:50', '2022-10-19 19:37:50', '', '7', '', 'inherit', 'open', 'closed', '', '7', '', '', '2022-10-19 22:51:59', '2022-10-19 19:51:59', '', 80, 'http://lindo/wp-content/uploads/2022/10/7.png', 0, 'attachment', 'image/png', 0),
(39, 1, '2022-10-19 22:37:57', '2022-10-19 19:37:57', '', '8', '', 'inherit', 'open', 'closed', '', '8', '', '', '2022-10-19 22:53:03', '2022-10-19 19:53:03', '', 82, 'http://lindo/wp-content/uploads/2022/10/8.png', 0, 'attachment', 'image/png', 0),
(40, 1, '2022-10-19 22:38:08', '2022-10-19 19:38:08', '', '9', '', 'inherit', 'open', 'closed', '', '9', '', '', '2022-10-19 22:56:32', '2022-10-19 19:56:32', '', 92, 'http://lindo/wp-content/uploads/2022/10/9.png', 0, 'attachment', 'image/png', 0),
(41, 1, '2022-10-19 22:38:17', '2022-10-19 19:38:17', '', '10', '', 'inherit', 'open', 'closed', '', '10', '', '', '2022-10-19 22:54:43', '2022-10-19 19:54:43', '', 86, 'http://lindo/wp-content/uploads/2022/10/10.png', 0, 'attachment', 'image/png', 0),
(42, 1, '2022-10-19 22:38:25', '2022-10-19 19:38:25', '', '11', '', 'inherit', 'open', 'closed', '', '11', '', '', '2022-10-19 22:55:51', '2022-10-19 19:55:51', '', 89, 'http://lindo/wp-content/uploads/2022/10/11.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2022-10-19 22:38:32', '2022-10-19 19:38:32', '', '12', '', 'inherit', 'open', 'closed', '', '12', '', '', '2022-10-19 22:58:09', '2022-10-19 19:58:09', '', 95, 'http://lindo/wp-content/uploads/2022/10/12.png', 0, 'attachment', 'image/png', 0),
(44, 1, '2022-10-19 22:38:49', '2022-10-19 19:38:49', '', '13', '', 'inherit', 'open', 'closed', '', '13', '', '', '2022-10-19 22:58:53', '2022-10-19 19:58:53', '', 98, 'http://lindo/wp-content/uploads/2022/10/13.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2022-10-19 22:38:57', '2022-10-19 19:38:57', '', '14', '', 'inherit', 'open', 'closed', '', '14', '', '', '2022-10-19 22:59:33', '2022-10-19 19:59:33', '', 101, 'http://lindo/wp-content/uploads/2022/10/14.png', 0, 'attachment', 'image/png', 0),
(46, 1, '2022-10-19 22:39:04', '2022-10-19 19:39:04', '', '15', '', 'inherit', 'open', 'closed', '', '15', '', '', '2022-10-19 23:00:15', '2022-10-19 20:00:15', '', 104, 'http://lindo/wp-content/uploads/2022/10/15.png', 0, 'attachment', 'image/png', 0),
(47, 1, '2022-10-19 22:39:13', '2022-10-19 19:39:13', '', '16', '', 'inherit', 'open', 'closed', '', '16', '', '', '2022-10-19 23:01:21', '2022-10-19 20:01:21', '', 107, 'http://lindo/wp-content/uploads/2022/10/16.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2022-10-19 22:39:20', '2022-10-19 19:39:20', '', '17', '', 'inherit', 'open', 'closed', '', '17', '', '', '2022-10-19 23:02:26', '2022-10-19 20:02:26', '', 110, 'http://lindo/wp-content/uploads/2022/10/17.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2022-10-19 22:39:28', '2022-10-19 19:39:28', '', '18', '', 'inherit', 'open', 'closed', '', '18', '', '', '2022-10-19 23:03:25', '2022-10-19 20:03:25', '', 113, 'http://lindo/wp-content/uploads/2022/10/18.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2022-10-19 22:39:33', '2022-10-19 19:39:33', '', '19', '', 'inherit', 'open', 'closed', '', '19', '', '', '2022-10-19 23:04:04', '2022-10-19 20:04:04', '', 116, 'http://lindo/wp-content/uploads/2022/10/19.png', 0, 'attachment', 'image/png', 0),
(51, 1, '2022-10-19 22:39:38', '2022-10-19 19:39:38', '', '20', '', 'inherit', 'open', 'closed', '', '20', '', '', '2022-10-19 23:04:43', '2022-10-19 20:04:43', '', 119, 'http://lindo/wp-content/uploads/2022/10/20.png', 0, 'attachment', 'image/png', 0),
(52, 1, '2022-10-19 22:39:41', '2022-10-19 19:39:41', '', '21', '', 'inherit', 'open', 'closed', '', '21', '', '', '2022-10-19 23:05:50', '2022-10-19 20:05:50', '', 122, 'http://lindo/wp-content/uploads/2022/10/21.png', 0, 'attachment', 'image/png', 0),
(53, 1, '2022-10-19 22:39:47', '2022-10-19 19:39:47', '', '22', '', 'inherit', 'open', 'closed', '', '22', '', '', '2022-10-19 23:06:54', '2022-10-19 20:06:54', '', 125, 'http://lindo/wp-content/uploads/2022/10/22.png', 0, 'attachment', 'image/png', 0),
(54, 1, '2022-10-19 22:39:54', '2022-10-19 19:39:54', '', '23', '', 'inherit', 'open', 'closed', '', '23', '', '', '2022-10-19 23:07:26', '2022-10-19 20:07:26', '', 128, 'http://lindo/wp-content/uploads/2022/10/23.png', 0, 'attachment', 'image/png', 0),
(55, 1, '2022-10-19 22:40:02', '2022-10-19 19:40:02', '', '24', '', 'inherit', 'open', 'closed', '', '24', '', '', '2022-10-19 23:08:03', '2022-10-19 20:08:03', '', 131, 'http://lindo/wp-content/uploads/2022/10/24.png', 0, 'attachment', 'image/png', 0),
(56, 1, '2022-10-19 22:40:08', '2022-10-19 19:40:08', '', '25', '', 'inherit', 'open', 'closed', '', '25', '', '', '2022-10-19 23:08:33', '2022-10-19 20:08:33', '', 134, 'http://lindo/wp-content/uploads/2022/10/25.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2022-10-19 22:40:11', '2022-10-19 19:40:11', '', '26', '', 'inherit', 'open', 'closed', '', '26', '', '', '2022-10-19 23:11:02', '2022-10-19 20:11:02', '', 140, 'http://lindo/wp-content/uploads/2022/10/26.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2022-10-19 22:40:15', '2022-10-19 19:40:15', '', '27', '', 'inherit', 'open', 'closed', '', '27', '', '', '2022-10-19 23:10:31', '2022-10-19 20:10:31', '', 137, 'http://lindo/wp-content/uploads/2022/10/27.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2022-10-19 22:40:21', '2022-10-19 19:40:21', '', '28', '', 'inherit', 'open', 'closed', '', '28', '', '', '2022-10-19 23:12:18', '2022-10-19 20:12:18', '', 145, 'http://lindo/wp-content/uploads/2022/10/28.png', 0, 'attachment', 'image/png', 0),
(60, 1, '2022-10-19 22:40:25', '2022-10-19 19:40:25', '', '29', '', 'inherit', 'open', 'closed', '', '29', '', '', '2022-10-19 23:11:41', '2022-10-19 20:11:41', '', 143, 'http://lindo/wp-content/uploads/2022/10/29.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2022-10-19 22:40:31', '2022-10-19 19:40:31', '', '30', '', 'inherit', 'open', 'closed', '', '30', '', '', '2022-10-19 23:13:32', '2022-10-19 20:13:32', '', 149, 'http://lindo/wp-content/uploads/2022/10/30.png', 0, 'attachment', 'image/png', 0),
(62, 1, '2022-10-19 22:40:37', '2022-10-19 19:40:37', '', 'Lindo catalog NEW 2', '', 'inherit', 'open', 'closed', '', 'lindo-catalog-new-2', '', '', '2022-10-19 23:14:22', '2022-10-19 20:14:22', '', 152, 'http://lindo/wp-content/uploads/2022/10/Lindo-catalog-NEW-2.png', 0, 'attachment', 'image/png', 0),
(63, 1, '2022-10-19 22:40:40', '2022-10-19 19:40:40', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2022-10-19 22:45:22', '2022-10-19 19:45:22', '', 65, 'http://lindo/wp-content/uploads/2022/10/1.png', 0, 'attachment', 'image/png', 0),
(64, 1, '2022-10-19 22:40:47', '2022-10-19 19:40:47', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2022-10-19 22:47:00', '2022-10-19 19:47:00', '', 68, 'http://lindo/wp-content/uploads/2022/10/2.png', 0, 'attachment', 'image/png', 0),
(65, 1, '2022-10-19 22:44:32', '2022-10-19 19:44:32', '', 'Florentis', '', 'publish', 'open', 'open', '', 'florentis', '', '', '2022-10-19 22:45:22', '2022-10-19 19:45:22', '', 0, 'http://lindo/?p=65', 0, 'post', '', 0),
(66, 1, '2022-10-19 22:45:19', '2022-10-19 19:45:19', '', 'Florentis', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2022-10-19 22:45:19', '2022-10-19 19:45:19', '', 65, 'http://lindo/?p=66', 0, 'revision', '', 0),
(67, 1, '2022-10-19 22:45:22', '2022-10-19 19:45:22', '', 'Florentis', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2022-10-19 22:45:22', '2022-10-19 19:45:22', '', 65, 'http://lindo/?p=67', 0, 'revision', '', 0),
(68, 1, '2022-10-19 22:46:55', '2022-10-19 19:46:55', '', 'Benicia', '', 'publish', 'open', 'open', '', 'benicia', '', '', '2022-10-19 22:47:00', '2022-10-19 19:47:00', '', 0, 'http://lindo/?p=68', 0, 'post', '', 0),
(69, 1, '2022-10-19 22:46:55', '2022-10-19 19:46:55', '', 'Benicia', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2022-10-19 22:46:55', '2022-10-19 19:46:55', '', 68, 'http://lindo/?p=69', 0, 'revision', '', 0),
(70, 1, '2022-10-19 22:47:00', '2022-10-19 19:47:00', '', 'Benicia', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2022-10-19 22:47:00', '2022-10-19 19:47:00', '', 68, 'http://lindo/?p=70', 0, 'revision', '', 0),
(71, 1, '2022-10-19 22:48:51', '2022-10-19 19:48:51', '', 'Victoria', '', 'publish', 'open', 'open', '', 'victoria', '', '', '2022-10-19 22:48:54', '2022-10-19 19:48:54', '', 0, 'http://lindo/?p=71', 0, 'post', '', 0),
(72, 1, '2022-10-19 22:48:51', '2022-10-19 19:48:51', '', 'Victoria', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2022-10-19 22:48:51', '2022-10-19 19:48:51', '', 71, 'http://lindo/?p=72', 0, 'revision', '', 0),
(73, 1, '2022-10-19 22:48:54', '2022-10-19 19:48:54', '', 'Victoria', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2022-10-19 22:48:54', '2022-10-19 19:48:54', '', 71, 'http://lindo/?p=73', 0, 'revision', '', 0),
(74, 1, '2022-10-19 22:49:57', '2022-10-19 19:49:57', '', 'Muhtasem', '', 'publish', 'open', 'open', '', 'muhtasem', '', '', '2022-10-19 22:50:01', '2022-10-19 19:50:01', '', 0, 'http://lindo/?p=74', 0, 'post', '', 0),
(75, 1, '2022-10-19 22:49:57', '2022-10-19 19:49:57', '', 'Muhtasem', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2022-10-19 22:49:57', '2022-10-19 19:49:57', '', 74, 'http://lindo/?p=75', 0, 'revision', '', 0),
(76, 1, '2022-10-19 22:50:01', '2022-10-19 19:50:01', '', 'Muhtasem', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2022-10-19 22:50:01', '2022-10-19 19:50:01', '', 74, 'http://lindo/?p=76', 0, 'revision', '', 0),
(77, 1, '2022-10-19 22:51:00', '2022-10-19 19:51:00', '', 'Levante', '', 'publish', 'open', 'open', '', 'levante', '', '', '2022-10-19 22:51:04', '2022-10-19 19:51:04', '', 0, 'http://lindo/?p=77', 0, 'post', '', 0),
(78, 1, '2022-10-19 22:51:00', '2022-10-19 19:51:00', '', 'Levante', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2022-10-19 22:51:00', '2022-10-19 19:51:00', '', 77, 'http://lindo/?p=78', 0, 'revision', '', 0),
(79, 1, '2022-10-19 22:51:04', '2022-10-19 19:51:04', '', 'Levante', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2022-10-19 22:51:04', '2022-10-19 19:51:04', '', 77, 'http://lindo/?p=79', 0, 'revision', '', 0),
(80, 1, '2022-10-19 22:51:54', '2022-10-19 19:51:54', '', 'President', '', 'publish', 'open', 'open', '', 'president', '', '', '2022-10-19 22:51:58', '2022-10-19 19:51:58', '', 0, 'http://lindo/?p=80', 0, 'post', '', 0),
(81, 1, '2022-10-19 22:51:54', '2022-10-19 19:51:54', '', 'President', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2022-10-19 22:51:54', '2022-10-19 19:51:54', '', 80, 'http://lindo/?p=81', 0, 'revision', '', 0),
(82, 1, '2022-10-19 22:53:00', '2022-10-19 19:53:00', '', 'Sweet&Milk', '', 'publish', 'open', 'open', '', 'sweetmilk', '', '', '2022-10-19 22:53:03', '2022-10-19 19:53:03', '', 0, 'http://lindo/?p=82', 0, 'post', '', 0),
(83, 1, '2022-10-19 22:51:58', '2022-10-19 19:51:58', '', 'President', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2022-10-19 22:51:58', '2022-10-19 19:51:58', '', 80, 'http://lindo/?p=83', 0, 'revision', '', 0),
(84, 1, '2022-10-19 22:53:00', '2022-10-19 19:53:00', '', 'Sweet&Milk', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2022-10-19 22:53:00', '2022-10-19 19:53:00', '', 82, 'http://lindo/?p=84', 0, 'revision', '', 0),
(85, 1, '2022-10-19 22:53:03', '2022-10-19 19:53:03', '', 'Sweet&Milk', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2022-10-19 22:53:03', '2022-10-19 19:53:03', '', 82, 'http://lindo/?p=85', 0, 'revision', '', 0),
(86, 1, '2022-10-19 22:54:40', '2022-10-19 19:54:40', '', 'Milan', '', 'publish', 'open', 'open', '', 'milan', '', '', '2022-10-19 22:54:43', '2022-10-19 19:54:43', '', 0, 'http://lindo/?p=86', 0, 'post', '', 0),
(87, 1, '2022-10-19 22:54:40', '2022-10-19 19:54:40', '', 'Milan', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2022-10-19 22:54:40', '2022-10-19 19:54:40', '', 86, 'http://lindo/?p=87', 0, 'revision', '', 0),
(88, 1, '2022-10-19 22:54:43', '2022-10-19 19:54:43', '', 'Milan', '', 'inherit', 'closed', 'closed', '', '86-revision-v1', '', '', '2022-10-19 22:54:43', '2022-10-19 19:54:43', '', 86, 'http://lindo/?p=88', 0, 'revision', '', 0),
(89, 1, '2022-10-19 22:55:47', '2022-10-19 19:55:47', '', 'Milano', '', 'publish', 'open', 'open', '', 'milano', '', '', '2022-10-19 22:55:51', '2022-10-19 19:55:51', '', 0, 'http://lindo/?p=89', 0, 'post', '', 0),
(90, 1, '2022-10-19 22:55:47', '2022-10-19 19:55:47', '', 'Milano', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2022-10-19 22:55:47', '2022-10-19 19:55:47', '', 89, 'http://lindo/?p=90', 0, 'revision', '', 0),
(91, 1, '2022-10-19 22:55:51', '2022-10-19 19:55:51', '', 'Milano', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2022-10-19 22:55:51', '2022-10-19 19:55:51', '', 89, 'http://lindo/?p=91', 0, 'revision', '', 0),
(92, 1, '2022-10-19 22:56:28', '2022-10-19 19:56:28', '', 'Florentis', '', 'publish', 'open', 'open', '', 'florentis-2', '', '', '2022-10-19 22:56:32', '2022-10-19 19:56:32', '', 0, 'http://lindo/?p=92', 0, 'post', '', 0),
(93, 1, '2022-10-19 22:56:28', '2022-10-19 19:56:28', '', 'Florentis', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2022-10-19 22:56:28', '2022-10-19 19:56:28', '', 92, 'http://lindo/?p=93', 0, 'revision', '', 0),
(94, 1, '2022-10-19 22:56:32', '2022-10-19 19:56:32', '', 'Florentis', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2022-10-19 22:56:32', '2022-10-19 19:56:32', '', 92, 'http://lindo/?p=94', 0, 'revision', '', 0),
(95, 1, '2022-10-19 22:58:05', '2022-10-19 19:58:05', '', '360°', '', 'publish', 'open', 'open', '', '360-2', '', '', '2022-10-19 22:58:09', '2022-10-19 19:58:09', '', 0, 'http://lindo/?p=95', 0, 'post', '', 0),
(96, 1, '2022-10-19 22:58:05', '2022-10-19 19:58:05', '', '360°', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2022-10-19 22:58:05', '2022-10-19 19:58:05', '', 95, 'http://lindo/?p=96', 0, 'revision', '', 0),
(97, 1, '2022-10-19 22:58:09', '2022-10-19 19:58:09', '', '360°', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2022-10-19 22:58:09', '2022-10-19 19:58:09', '', 95, 'http://lindo/?p=97', 0, 'revision', '', 0),
(98, 1, '2022-10-19 22:58:49', '2022-10-19 19:58:49', '', 'Delice', '', 'publish', 'open', 'open', '', 'delice', '', '', '2022-10-19 22:58:53', '2022-10-19 19:58:53', '', 0, 'http://lindo/?p=98', 0, 'post', '', 0),
(99, 1, '2022-10-19 22:58:49', '2022-10-19 19:58:49', '', 'Delice', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2022-10-19 22:58:49', '2022-10-19 19:58:49', '', 98, 'http://lindo/?p=99', 0, 'revision', '', 0),
(100, 1, '2022-10-19 22:58:53', '2022-10-19 19:58:53', '', 'Delice', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2022-10-19 22:58:53', '2022-10-19 19:58:53', '', 98, 'http://lindo/?p=100', 0, 'revision', '', 0),
(101, 1, '2022-10-19 22:59:29', '2022-10-19 19:59:29', '', 'Compete', '', 'publish', 'open', 'open', '', 'compete', '', '', '2022-10-19 22:59:33', '2022-10-19 19:59:33', '', 0, 'http://lindo/?p=101', 0, 'post', '', 0),
(102, 1, '2022-10-19 22:59:29', '2022-10-19 19:59:29', '', 'Compete', '', 'inherit', 'closed', 'closed', '', '101-revision-v1', '', '', '2022-10-19 22:59:29', '2022-10-19 19:59:29', '', 101, 'http://lindo/?p=102', 0, 'revision', '', 0),
(103, 1, '2022-10-19 22:59:33', '2022-10-19 19:59:33', '', 'Compete', '', 'inherit', 'closed', 'closed', '', '101-revision-v1', '', '', '2022-10-19 22:59:33', '2022-10-19 19:59:33', '', 101, 'http://lindo/?p=103', 0, 'revision', '', 0),
(104, 1, '2022-10-19 23:00:11', '2022-10-19 20:00:11', '', 'Chocolay', '', 'publish', 'open', 'open', '', 'chocolay', '', '', '2022-10-19 23:00:15', '2022-10-19 20:00:15', '', 0, 'http://lindo/?p=104', 0, 'post', '', 0),
(105, 1, '2022-10-19 23:00:11', '2022-10-19 20:00:11', '', 'Chocolay', '', 'inherit', 'closed', 'closed', '', '104-revision-v1', '', '', '2022-10-19 23:00:11', '2022-10-19 20:00:11', '', 104, 'http://lindo/?p=105', 0, 'revision', '', 0),
(106, 1, '2022-10-19 23:00:15', '2022-10-19 20:00:15', '', 'Chocolay', '', 'inherit', 'closed', 'closed', '', '104-revision-v1', '', '', '2022-10-19 23:00:15', '2022-10-19 20:00:15', '', 104, 'http://lindo/?p=106', 0, 'revision', '', 0),
(107, 1, '2022-10-19 23:01:18', '2022-10-19 20:01:18', '', '360° kg', '', 'publish', 'open', 'open', '', '360-kg', '', '', '2022-10-19 23:01:20', '2022-10-19 20:01:20', '', 0, 'http://lindo/?p=107', 0, 'post', '', 0),
(108, 1, '2022-10-19 23:01:18', '2022-10-19 20:01:18', '', '360° kg', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2022-10-19 23:01:18', '2022-10-19 20:01:18', '', 107, 'http://lindo/?p=108', 0, 'revision', '', 0),
(109, 1, '2022-10-19 23:01:20', '2022-10-19 20:01:20', '', '360° kg', '', 'inherit', 'closed', 'closed', '', '107-revision-v1', '', '', '2022-10-19 23:01:20', '2022-10-19 20:01:20', '', 107, 'http://lindo/?p=109', 0, 'revision', '', 0),
(110, 1, '2022-10-19 23:02:23', '2022-10-19 20:02:23', '', 'Палочка', '', 'publish', 'open', 'open', '', '%d0%bf%d0%b0%d0%bb%d0%be%d1%87%d0%ba%d0%b0', '', '', '2022-10-19 23:02:26', '2022-10-19 20:02:26', '', 0, 'http://lindo/?p=110', 0, 'post', '', 0),
(111, 1, '2022-10-19 23:02:23', '2022-10-19 20:02:23', '', 'Палочка', '', 'inherit', 'closed', 'closed', '', '110-revision-v1', '', '', '2022-10-19 23:02:23', '2022-10-19 20:02:23', '', 110, 'http://lindo/?p=111', 0, 'revision', '', 0),
(112, 1, '2022-10-19 23:02:26', '2022-10-19 20:02:26', '', 'Палочка', '', 'inherit', 'closed', 'closed', '', '110-revision-v1', '', '', '2022-10-19 23:02:26', '2022-10-19 20:02:26', '', 110, 'http://lindo/?p=112', 0, 'revision', '', 0),
(113, 1, '2022-10-19 23:03:21', '2022-10-19 20:03:21', '', 'Hi-Tech', '', 'publish', 'open', 'open', '', 'hi-tech', '', '', '2022-10-19 23:03:25', '2022-10-19 20:03:25', '', 0, 'http://lindo/?p=113', 0, 'post', '', 0),
(114, 1, '2022-10-19 23:03:21', '2022-10-19 20:03:21', '', 'Hi-Tech', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2022-10-19 23:03:21', '2022-10-19 20:03:21', '', 113, 'http://lindo/?p=114', 0, 'revision', '', 0),
(115, 1, '2022-10-19 23:03:25', '2022-10-19 20:03:25', '', 'Hi-Tech', '', 'inherit', 'closed', 'closed', '', '113-revision-v1', '', '', '2022-10-19 23:03:25', '2022-10-19 20:03:25', '', 113, 'http://lindo/?p=115', 0, 'revision', '', 0),
(116, 1, '2022-10-19 23:04:00', '2022-10-19 20:04:00', '', 'Cappuccino', '', 'publish', 'open', 'open', '', 'cappuccino', '', '', '2022-10-19 23:04:04', '2022-10-19 20:04:04', '', 0, 'http://lindo/?p=116', 0, 'post', '', 0),
(117, 1, '2022-10-19 23:04:00', '2022-10-19 20:04:00', '', 'Cappuccino', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2022-10-19 23:04:00', '2022-10-19 20:04:00', '', 116, 'http://lindo/?p=117', 0, 'revision', '', 0),
(118, 1, '2022-10-19 23:04:04', '2022-10-19 20:04:04', '', 'Cappuccino', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2022-10-19 23:04:04', '2022-10-19 20:04:04', '', 116, 'http://lindo/?p=118', 0, 'revision', '', 0),
(119, 1, '2022-10-19 23:04:37', '2022-10-19 20:04:37', '', 'LOCHIRA', '', 'publish', 'open', 'open', '', 'lochira', '', '', '2022-10-19 23:04:42', '2022-10-19 20:04:42', '', 0, 'http://lindo/?p=119', 0, 'post', '', 0),
(120, 1, '2022-10-19 23:04:37', '2022-10-19 20:04:37', '', 'LOCHIRA', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2022-10-19 23:04:37', '2022-10-19 20:04:37', '', 119, 'http://lindo/?p=120', 0, 'revision', '', 0),
(121, 1, '2022-10-19 23:04:42', '2022-10-19 20:04:42', '', 'LOCHIRA', '', 'inherit', 'closed', 'closed', '', '119-revision-v1', '', '', '2022-10-19 23:04:42', '2022-10-19 20:04:42', '', 119, 'http://lindo/?p=121', 0, 'revision', '', 0),
(122, 1, '2022-10-19 23:05:45', '2022-10-19 20:05:45', '', 'LOCHIRA', '', 'publish', 'open', 'open', '', 'lochira-2', '', '', '2022-10-19 23:05:49', '2022-10-19 20:05:49', '', 0, 'http://lindo/?p=122', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(123, 1, '2022-10-19 23:05:45', '2022-10-19 20:05:45', '', 'LOCHIRA', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2022-10-19 23:05:45', '2022-10-19 20:05:45', '', 122, 'http://lindo/?p=123', 0, 'revision', '', 0),
(124, 1, '2022-10-19 23:05:49', '2022-10-19 20:05:49', '', 'LOCHIRA', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2022-10-19 23:05:49', '2022-10-19 20:05:49', '', 122, 'http://lindo/?p=124', 0, 'revision', '', 0),
(125, 1, '2022-10-19 23:06:51', '2022-10-19 20:06:51', '', 'KUNJUTLI', '', 'publish', 'open', 'open', '', 'kunjutli', '', '', '2022-10-19 23:06:54', '2022-10-19 20:06:54', '', 0, 'http://lindo/?p=125', 0, 'post', '', 0),
(126, 1, '2022-10-19 23:06:51', '2022-10-19 20:06:51', '', 'KUNJUTLI', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2022-10-19 23:06:51', '2022-10-19 20:06:51', '', 125, 'http://lindo/?p=126', 0, 'revision', '', 0),
(127, 1, '2022-10-19 23:06:54', '2022-10-19 20:06:54', '', 'KUNJUTLI', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2022-10-19 23:06:54', '2022-10-19 20:06:54', '', 125, 'http://lindo/?p=127', 0, 'revision', '', 0),
(128, 1, '2022-10-19 23:07:22', '2022-10-19 20:07:22', '', 'Cappuccino', '', 'publish', 'open', 'open', '', 'cappuccino-2', '', '', '2022-10-19 23:07:26', '2022-10-19 20:07:26', '', 0, 'http://lindo/?p=128', 0, 'post', '', 0),
(129, 1, '2022-10-19 23:07:22', '2022-10-19 20:07:22', '', 'Cappuccino', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2022-10-19 23:07:22', '2022-10-19 20:07:22', '', 128, 'http://lindo/?p=129', 0, 'revision', '', 0),
(130, 1, '2022-10-19 23:07:26', '2022-10-19 20:07:26', '', 'Cappuccino', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2022-10-19 23:07:26', '2022-10-19 20:07:26', '', 128, 'http://lindo/?p=130', 0, 'revision', '', 0),
(131, 1, '2022-10-19 23:08:00', '2022-10-19 20:08:00', '', 'LINDO', '', 'publish', 'open', 'open', '', 'lindo', '', '', '2022-10-19 23:08:03', '2022-10-19 20:08:03', '', 0, 'http://lindo/?p=131', 0, 'post', '', 0),
(132, 1, '2022-10-19 23:08:00', '2022-10-19 20:08:00', '', 'LINDO', '', 'inherit', 'closed', 'closed', '', '131-revision-v1', '', '', '2022-10-19 23:08:00', '2022-10-19 20:08:00', '', 131, 'http://lindo/?p=132', 0, 'revision', '', 0),
(133, 1, '2022-10-19 23:08:03', '2022-10-19 20:08:03', '', 'LINDO', '', 'inherit', 'closed', 'closed', '', '131-revision-v1', '', '', '2022-10-19 23:08:03', '2022-10-19 20:08:03', '', 131, 'http://lindo/?p=133', 0, 'revision', '', 0),
(134, 1, '2022-10-19 23:08:30', '2022-10-19 20:08:30', '', 'LINDO', '', 'publish', 'open', 'open', '', 'lindo-2', '', '', '2022-10-19 23:08:33', '2022-10-19 20:08:33', '', 0, 'http://lindo/?p=134', 0, 'post', '', 0),
(135, 1, '2022-10-19 23:08:30', '2022-10-19 20:08:30', '', 'LINDO', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2022-10-19 23:08:30', '2022-10-19 20:08:30', '', 134, 'http://lindo/?p=135', 0, 'revision', '', 0),
(136, 1, '2022-10-19 23:08:33', '2022-10-19 20:08:33', '', 'LINDO', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2022-10-19 23:08:33', '2022-10-19 20:08:33', '', 134, 'http://lindo/?p=136', 0, 'revision', '', 0),
(137, 1, '2022-10-19 23:10:28', '2022-10-19 20:10:28', '', 'HI-TECH', '', 'publish', 'open', 'open', '', 'hi-tech-2', '', '', '2022-10-19 23:10:31', '2022-10-19 20:10:31', '', 0, 'http://lindo/?p=137', 0, 'post', '', 0),
(138, 1, '2022-10-19 23:10:28', '2022-10-19 20:10:28', '', 'HI-TECH', '', 'inherit', 'closed', 'closed', '', '137-revision-v1', '', '', '2022-10-19 23:10:28', '2022-10-19 20:10:28', '', 137, 'http://lindo/?p=138', 0, 'revision', '', 0),
(139, 1, '2022-10-19 23:10:31', '2022-10-19 20:10:31', '', 'HI-TECH', '', 'inherit', 'closed', 'closed', '', '137-revision-v1', '', '', '2022-10-19 23:10:31', '2022-10-19 20:10:31', '', 137, 'http://lindo/?p=139', 0, 'revision', '', 0),
(140, 1, '2022-10-19 23:10:59', '2022-10-19 20:10:59', '', 'HI-TECH', '', 'publish', 'open', 'open', '', 'hi-tech-3', '', '', '2022-10-19 23:11:02', '2022-10-19 20:11:02', '', 0, 'http://lindo/?p=140', 0, 'post', '', 0),
(141, 1, '2022-10-19 23:10:59', '2022-10-19 20:10:59', '', 'HI-TECH', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2022-10-19 23:10:59', '2022-10-19 20:10:59', '', 140, 'http://lindo/?p=141', 0, 'revision', '', 0),
(142, 1, '2022-10-19 23:11:02', '2022-10-19 20:11:02', '', 'HI-TECH', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2022-10-19 23:11:02', '2022-10-19 20:11:02', '', 140, 'http://lindo/?p=142', 0, 'revision', '', 0),
(143, 1, '2022-10-19 23:11:37', '2022-10-19 20:11:37', '', 'КОРОВКА', '', 'publish', 'open', 'open', '', '%d0%ba%d0%be%d1%80%d0%be%d0%b2%d0%ba%d0%b0', '', '', '2022-10-19 23:11:41', '2022-10-19 20:11:41', '', 0, 'http://lindo/?p=143', 0, 'post', '', 0),
(144, 1, '2022-10-19 23:11:37', '2022-10-19 20:11:37', '', 'КОРОВКА', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2022-10-19 23:11:37', '2022-10-19 20:11:37', '', 143, 'http://lindo/?p=144', 0, 'revision', '', 0),
(145, 1, '2022-10-19 23:12:14', '2022-10-19 20:12:14', '', 'ЮБИЛЕЙНОЕ', '', 'publish', 'open', 'open', '', '%d1%8e%d0%b1%d0%b8%d0%bb%d0%b5%d0%b9%d0%bd%d0%be%d0%b5', '', '', '2022-10-19 23:12:17', '2022-10-19 20:12:17', '', 0, 'http://lindo/?p=145', 0, 'post', '', 0),
(146, 1, '2022-10-19 23:11:41', '2022-10-19 20:11:41', '', 'КОРОВКА', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2022-10-19 23:11:41', '2022-10-19 20:11:41', '', 143, 'http://lindo/?p=146', 0, 'revision', '', 0),
(147, 1, '2022-10-19 23:12:14', '2022-10-19 20:12:14', '', 'ЮБИЛЕЙНОЕ', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2022-10-19 23:12:14', '2022-10-19 20:12:14', '', 145, 'http://lindo/?p=147', 0, 'revision', '', 0),
(148, 1, '2022-10-19 23:12:17', '2022-10-19 20:12:17', '', 'ЮБИЛЕЙНОЕ', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2022-10-19 23:12:17', '2022-10-19 20:12:17', '', 145, 'http://lindo/?p=148', 0, 'revision', '', 0),
(149, 1, '2022-10-19 23:13:29', '2022-10-19 20:13:29', '', 'Топленое', '', 'publish', 'open', 'open', '', '%d1%82%d0%be%d0%bf%d0%bb%d0%b5%d0%bd%d0%be%d0%b5', '', '', '2022-10-19 23:13:32', '2022-10-19 20:13:32', '', 0, 'http://lindo/?p=149', 0, 'post', '', 0),
(150, 1, '2022-10-19 23:13:29', '2022-10-19 20:13:29', '', 'Топленое', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2022-10-19 23:13:29', '2022-10-19 20:13:29', '', 149, 'http://lindo/?p=150', 0, 'revision', '', 0),
(151, 1, '2022-10-19 23:13:32', '2022-10-19 20:13:32', '', 'Топленое', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2022-10-19 23:13:32', '2022-10-19 20:13:32', '', 149, 'http://lindo/?p=151', 0, 'revision', '', 0),
(152, 1, '2022-10-19 23:14:18', '2022-10-19 20:14:18', '', 'Coffe', '', 'publish', 'open', 'open', '', 'coffe', '', '', '2022-10-19 23:14:22', '2022-10-19 20:14:22', '', 0, 'http://lindo/?p=152', 0, 'post', '', 0),
(153, 1, '2022-10-19 23:14:18', '2022-10-19 20:14:18', '', 'Coffe', '', 'inherit', 'closed', 'closed', '', '152-revision-v1', '', '', '2022-10-19 23:14:18', '2022-10-19 20:14:18', '', 152, 'http://lindo/?p=153', 0, 'revision', '', 0),
(154, 1, '2022-10-19 23:14:22', '2022-10-19 20:14:22', '', 'Coffe', '', 'inherit', 'closed', 'closed', '', '152-revision-v1', '', '', '2022-10-19 23:14:22', '2022-10-19 20:14:22', '', 152, 'http://lindo/?p=154', 0, 'revision', '', 0),
(157, 1, '2023-01-22 02:25:59', '2023-01-21 23:25:59', 'uz_UZ', 'Uzbek', '', 'publish', 'closed', 'closed', '', 'uzbek', '', '', '2023-01-22 02:25:59', '2023-01-21 23:25:59', '', 0, 'http://lindo/language_switcher/uzbek/', 0, 'language_switcher', '', 0),
(158, 1, '2023-01-22 02:25:59', '2023-01-21 23:25:59', 'ru_RU', 'Russian', '', 'publish', 'closed', 'closed', '', 'russian', '', '', '2023-01-22 02:25:59', '2023-01-21 23:25:59', '', 0, 'http://lindo/language_switcher/russian/', 0, 'language_switcher', '', 0),
(159, 1, '2023-01-22 02:25:59', '2023-01-21 23:25:59', 'current_language', 'Current Language', '', 'publish', 'closed', 'closed', '', 'current-language', '', '', '2023-01-22 02:25:59', '2023-01-21 23:25:59', '', 0, 'http://lindo/language_switcher/current-language/', 0, 'language_switcher', '', 0),
(160, 1, '2023-01-22 02:25:59', '2023-01-21 23:25:59', 'opposite_language', 'Opposite Language', '', 'publish', 'closed', 'closed', '', 'opposite-language', '', '', '2023-01-22 02:25:59', '2023-01-21 23:25:59', '', 0, 'http://lindo/language_switcher/opposite-language/', 0, 'language_switcher', '', 0),
(162, 1, '2023-05-06 11:42:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-05-06 11:42:33', '0000-00-00 00:00:00', '', 0, 'http://lindo/?p=162', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(8, 2, 0),
(65, 3, 0),
(68, 3, 0),
(71, 3, 0),
(74, 3, 0),
(77, 3, 0),
(80, 3, 0),
(82, 3, 0),
(86, 3, 0),
(89, 3, 0),
(92, 3, 0),
(95, 3, 0),
(98, 3, 0),
(101, 3, 0),
(104, 3, 0),
(107, 3, 0),
(110, 3, 0),
(113, 3, 0),
(116, 3, 0),
(119, 3, 0),
(122, 3, 0),
(125, 3, 0),
(128, 3, 0),
(131, 3, 0),
(134, 3, 0),
(137, 3, 0),
(140, 3, 0),
(143, 3, 0),
(145, 3, 0),
(149, 3, 0),
(152, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'category', 'Botda lindani all products oynasidagi praductala joylashgan ', 0, 30) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'lindo', 'lindo', 0),
(3, 'lindoProducts', 'lindo_products', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_dictionary_uz_uz_ru_ru`
#

DROP TABLE IF EXISTS `wp_trp_dictionary_uz_uz_ru_ru`;


#
# Table structure of table `wp_trp_dictionary_uz_uz_ru_ru`
#

CREATE TABLE `wp_trp_dictionary_uz_uz_ru_ru` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` int(20) DEFAULT '0',
  `block_type` int(20) DEFAULT '0',
  `original_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `index_name` (`original`(100)),
  FULLTEXT KEY `original_fulltext` (`original`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_dictionary_uz_uz_ru_ru`
#
INSERT INTO `wp_trp_dictionary_uz_uz_ru_ru` ( `id`, `original`, `translated`, `status`, `block_type`, `original_id`) VALUES
(1, 'About us', '', 0, 0, 1),
(2, 'Products', '', 0, 0, 2),
(3, 'Contacts', '', 0, 0, 3),
(4, 'LINDO', '', 0, 0, 4),
(5, 'Glazurlangan pecheniya karameli bilan', 'Глазированное печенье с карамелью', 2, 0, 5),
(6, 'Bog\'lanish', 'звонить', 2, 0, 6),
(7, 'Milano', '', 0, 0, 7),
(8, 'shokoladli konfetlar', 'шоколадные конфеты', 2, 0, 8),
(9, 'Sweet & Milk', '', 0, 0, 9),
(10, 'Billion', '', 0, 0, 10),
(11, 'Feel', '', 0, 0, 11),
(12, 'Victoria', '', 0, 0, 12),
(13, 'LINDA', '', 0, 0, 13),
(14, 'Linda shkalat', '', 0, 0, 14),
(15, 'kg shokalat', '', 0, 0, 15),
(16, 'Prezident', '', 0, 0, 16),
(17, 'kg shkalat', '', 0, 0, 17),
(18, 'Lindo Plitka', 'Lindo Плитка', 2, 0, 18),
(19, 'button', '', 0, 0, 19),
(20, 'СЛАДОСТИ СДЕЛАННЫЕ\r\n                    С ДУШОЙ', '', 0, 0, 20),
(21, 'Florentis', '', 0, 0, 21),
(22, 'Benicia', '', 0, 0, 22),
(23, 'Muhtasem', '', 0, 0, 23),
(24, 'Levante', '', 0, 0, 24),
(25, 'President', '', 0, 0, 25),
(26, 'Sweet&Milk', '', 0, 0, 26),
(27, '360°', '', 0, 0, 27),
(28, 'Delice', '', 0, 0, 28),
(29, 'Compete', '', 0, 0, 29),
(30, 'Chocolay', '', 0, 0, 30),
(31, '360° kg', '', 0, 0, 31),
(32, 'Палочка', '', 0, 0, 32),
(33, 'Hi-Tech', '', 0, 0, 33),
(34, 'Cappuccino', '', 0, 0, 34),
(35, 'LOCHIRA', '', 0, 0, 35),
(36, 'KUNJUTLI', '', 0, 0, 36),
(37, 'HI-TECH', '', 0, 0, 37),
(38, 'КОРОВКА', '', 0, 0, 38),
(39, 'ЮБИЛЕЙНОЕ', '', 0, 0, 39),
(40, 'Топленое', '', 0, 0, 40),
(41, 'Coffee', '', 0, 0, 41),
(42, 'view more', '', 0, 0, 42),
(43, 'Lindo', '', 0, 0, 43),
(44, '«Lindo Confectionery» - это традиции высокого качества, тшательность в мельчайших деталях,\r\n                            безупречность исполнения и непревзойденный вкус удовольствия!\r\n                            Разрабатывая сладости, прежде всего, мы думаем о наших потребителях. Мы хотим, что бы наши\r\n                            изделия приносили радость в каждый дом, и счастья становилось больше!\r\n                            Не останавливаясь в своем стремлении к совершенству, мы сочетаем\r\n                            профессиональную работу и натуральные ингредиенты.\r\n                            Наши основные принципы:\r\n                            • используем только высококачественное сырье;\r\n                            • концентрируем внимание на контроле качества готовой продукции;\r\n                            • стремимся к достижению оптимального сочетания цена — качество;\r\n                            • поиск новых идей.\r\n                            В планах развития «Lindo Confectionery» увеличение доли продукции на кондитерском рынке\r\n                            Республики Узбекистан, модернизация производства и совершенствование технологических\r\n                            процессов производства.\r\n                            Особое внимание будет уделяться также системе продаж, как одной из важных\r\n                            составляющих эффективной деятельности предприятия.', '', 0, 0, 44),
(45, 'LINDO email', '', 0, 0, 45),
(46, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio laborum praesentium\r\n                            suscipit!', '', 0, 0, 46),
(47, 'Izox qoldirish', '', 0, 0, 47),
(48, 'Izox', '', 0, 0, 48),
(49, 'izox', 'Отправить сообщение', 2, 0, 49),
(50, 'Biz bilan telefon orqali aloqaga chiqing', 'Свяжитесь с нами по телефону', 2, 0, 50),
(51, 'LINDO Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum molestias,\r\n                                quidem.', '', 0, 0, 51),
(52, 'Telefon nomer', '', 0, 0, 52),
(53, 'LINDO chocalate', '', 0, 0, 53),
(54, 'plato.uz', '', 0, 0, 54),
(55, 'http://lindo/wp-content/themes/lindo/assets/img/lindoLogo.png', '', 0, 0, 55),
(56, 'https://img.icons8.com/color/48/000000/uzbekistan.png', '', 0, 0, 56),
(57, 'https://img.icons8.com/color/48/000000/russian-federation.png', '', 0, 0, 57),
(58, 'https://img.icons8.com/color/48/000000/usa.png', '', 0, 0, 58),
(59, 'http://lindo/wp-content/themes/lindo/assets/img/remove/360.png', '', 0, 0, 59),
(60, 'http://lindo/wp-content/themes/lindo/assets/img/remove/milano.png', '', 0, 0, 60),
(61, 'http://lindo/wp-content/themes/lindo/assets/img/remove/sweet&milk.png', '', 0, 0, 61),
(62, 'http://lindo/wp-content/themes/lindo/assets/img/remove/billion.png', '', 0, 0, 62),
(63, 'http://lindo/wp-content/themes/lindo/assets/img/remove/feel.png', '', 0, 0, 63),
(64, 'http://lindo/wp-content/themes/lindo/assets/img/remove/vectoria.png', '', 0, 0, 64),
(65, 'http://lindo/wp-content/themes/lindo/assets/img/remove/lindoShkalat.png', '', 0, 0, 65),
(66, 'http://lindo/wp-content/themes/lindo/assets/img/remove/prezident.png', '', 0, 0, 66),
(67, 'http://lindo/wp-content/themes/lindo/assets/img/remove/lindoPlitka.png', '', 0, 0, 67),
(68, 'http://lindo/wp-content/uploads/2022/10/1.png', '', 0, 0, 68),
(69, 'http://lindo/wp-content/uploads/2022/10/2.png', '', 0, 0, 69),
(70, 'http://lindo/wp-content/uploads/2022/10/3.png', '', 0, 0, 70),
(71, 'http://lindo/wp-content/uploads/2022/10/5.png', '', 0, 0, 71),
(72, 'http://lindo/wp-content/uploads/2022/10/6.png', '', 0, 0, 72),
(73, 'http://lindo/wp-content/uploads/2022/10/7.png', '', 0, 0, 73),
(74, 'http://lindo/wp-content/uploads/2022/10/8.png', '', 0, 0, 74),
(75, 'http://lindo/wp-content/uploads/2022/10/10.png', '', 0, 0, 75),
(76, 'http://lindo/wp-content/uploads/2022/10/11.png', '', 0, 0, 76),
(77, 'http://lindo/wp-content/uploads/2022/10/9.png', '', 0, 0, 77),
(78, 'http://lindo/wp-content/uploads/2022/10/12.png', '', 0, 0, 78),
(79, 'http://lindo/wp-content/uploads/2022/10/13.png', '', 0, 0, 79),
(80, 'http://lindo/wp-content/uploads/2022/10/14.png', '', 0, 0, 80),
(81, 'http://lindo/wp-content/uploads/2022/10/15.png', '', 0, 0, 81),
(82, 'http://lindo/wp-content/uploads/2022/10/16.png', '', 0, 0, 82),
(83, 'http://lindo/wp-content/uploads/2022/10/17.png', '', 0, 0, 83),
(84, 'http://lindo/wp-content/uploads/2022/10/18.png', '', 0, 0, 84),
(85, 'http://lindo/wp-content/uploads/2022/10/19.png', '', 0, 0, 85),
(86, 'http://lindo/wp-content/uploads/2022/10/20.png', '', 0, 0, 86),
(87, 'http://lindo/wp-content/uploads/2022/10/21.png', '', 0, 0, 87),
(88, 'http://lindo/wp-content/uploads/2022/10/22.png', '', 0, 0, 88),
(89, 'http://lindo/wp-content/uploads/2022/10/23.png', '', 0, 0, 89),
(90, 'http://lindo/wp-content/uploads/2022/10/24.png', '', 0, 0, 90),
(91, 'http://lindo/wp-content/uploads/2022/10/25.png', '', 0, 0, 91),
(92, 'http://lindo/wp-content/uploads/2022/10/27.png', '', 0, 0, 92),
(93, 'http://lindo/wp-content/uploads/2022/10/26.png', '', 0, 0, 93),
(94, 'http://lindo/wp-content/uploads/2022/10/29.png', '', 0, 0, 94),
(95, 'http://lindo/wp-content/uploads/2022/10/28.png', '', 0, 0, 95),
(96, 'http://lindo/wp-content/uploads/2022/10/30.png', '', 0, 0, 96),
(97, 'http://lindo/wp-content/uploads/2022/10/Lindo-catalog-NEW-2.png', '', 0, 0, 97),
(98, 'tel:+9981234567', '', 0, 0, 98),
(99, 'https://platogroup.uz', '', 0, 0, 99),
(100, '1 of 30', '', 0, 0, 100) ;
INSERT INTO `wp_trp_dictionary_uz_uz_ru_ru` ( `id`, `original`, `translated`, `status`, `block_type`, `original_id`) VALUES
(101, '2 of 30', '', 0, 0, 101),
(102, '3 of 30', '', 0, 0, 102),
(103, '4 of 30', '', 0, 0, 103),
(104, '5 of 30', '', 0, 0, 104),
(105, '6 of 30', '', 0, 0, 105),
(106, '7 of 30', '', 0, 0, 106),
(107, '8 of 30', '', 0, 0, 107),
(108, '9 of 30', '', 0, 0, 108),
(109, '10 of 30', '', 0, 0, 109),
(110, '11 of 30', '', 0, 0, 110),
(111, '12 of 30', '', 0, 0, 111),
(112, '13 of 30', '', 0, 0, 112),
(113, '14 of 30', '', 0, 0, 113),
(114, '15 of 30', '', 0, 0, 114),
(115, '16 of 30', '', 0, 0, 115),
(116, '17 of 30', '', 0, 0, 116),
(117, '18 of 30', '', 0, 0, 117),
(118, '19 of 30', '', 0, 0, 118),
(119, '20 of 30', '', 0, 0, 119),
(120, '21 of 30', '', 0, 0, 120),
(121, '22 of 30', '', 0, 0, 121),
(122, '23 of 30', '', 0, 0, 122),
(123, '24 of 30', '', 0, 0, 123),
(124, '25 of 30', '', 0, 0, 124),
(125, '26 of 30', '', 0, 0, 125),
(126, '27 of 30', '', 0, 0, 126),
(127, '28 of 30', '', 0, 0, 127),
(128, '29 of 30', '', 0, 0, 128),
(129, '30 of 30', '', 0, 0, 129),
(130, 'Go to last slide', '', 0, 0, 130),
(131, 'Next slide', '', 0, 0, 131),
(132, 'Select a slide to show', '', 0, 0, 132),
(133, 'Go to slide 1', '', 0, 0, 133),
(134, 'Go to slide 2', '', 0, 0, 134),
(135, 'Go to slide 3', '', 0, 0, 135),
(136, 'Go to slide 4', '', 0, 0, 136),
(137, 'Go to slide 5', '', 0, 0, 137),
(138, 'Go to slide 6', '', 0, 0, 138),
(139, 'Go to slide 7', '', 0, 0, 139),
(140, 'Go to slide 8', '', 0, 0, 140),
(141, 'Go to slide 9', '', 0, 0, 141),
(142, 'Go to slide 10', '', 0, 0, 142),
(143, 'Go to slide 11', '', 0, 0, 143),
(144, 'Go to slide 12', '', 0, 0, 144),
(145, 'Go to slide 13', '', 0, 0, 145),
(146, 'Go to slide 14', '', 0, 0, 146),
(147, 'Go to slide 15', '', 0, 0, 147),
(148, 'Go to slide 16', '', 0, 0, 148),
(149, 'Go to slide 17', '', 0, 0, 149),
(150, 'Go to slide 18', '', 0, 0, 150),
(151, 'Go to slide 19', '', 0, 0, 151),
(152, 'Go to slide 20', '', 0, 0, 152),
(153, 'Go to slide 21', '', 0, 0, 153),
(154, 'Go to slide 22', '', 0, 0, 154),
(155, 'Go to slide 23', '', 0, 0, 155),
(156, 'Go to slide 24', '', 0, 0, 156),
(157, 'Go to slide 25', '', 0, 0, 157),
(158, 'Go to slide 26', '', 0, 0, 158),
(159, 'Go to slide 27', '', 0, 0, 159),
(160, 'Go to slide 28', '', 0, 0, 160),
(161, 'Go to slide 29', '', 0, 0, 161),
(162, 'Go to slide 30', '', 0, 0, 162),
(163, 'Biz haqimizda', 'О нас', 2, 0, 163),
(164, 'Maxsulotlar', 'Продукты', 2, 0, 164),
(165, 'Biz bilan aloqa', 'Свяжитесь с нами', 2, 0, 165),
(166, '«Lindo Confectionery» - это традиции высокого качества, тшательность в мельчайших деталях,', '"Lindo Confectionery" - bu yuqori sifat, eng mayda detallarda puxtalik,', 2, 0, 166),
(167, 'безупречность исполнения и непревзойденный вкус удовольствия!', 'benuqson ishlash va zavqning beqiyos ta\'mi!', 2, 0, 167),
(168, 'Разрабатывая сладости, прежде всего, мы думаем о наших потребителях. Мы хотим, что бы наши', '', 0, 0, 168),
(169, 'изделия приносили радость в каждый дом, и счастья становилось больше!', '', 0, 0, 169),
(170, 'Не останавливаясь в своем стремлении к совершенству, мы сочетаем', '', 0, 0, 170),
(171, 'профессиональную работу и натуральные ингредиенты.', '', 0, 0, 171),
(172, 'Наши основные принципы:', '', 0, 0, 172),
(173, '• используем только высококачественное сырье;', '', 0, 0, 173),
(174, '• концентрируем внимание на контроле качества готовой продукции;', '', 0, 0, 174),
(175, '• стремимся к достижению оптимального сочетания цена — качество;', '', 0, 0, 175),
(176, '• поиск новых идей.', '', 0, 0, 176),
(177, 'В планах развития «Lindo Confectionery» увеличение доли продукции на кондитерском рынке', '', 0, 0, 177),
(178, 'Республики Узбекистан, модернизация производства и совершенствование технологических', '', 0, 0, 178),
(179, 'процессов производства.', '', 0, 0, 179),
(180, 'Особое внимание будет уделяться также системе продаж, как одной из важных\r\n                            составляющих эффективной деятельности предприятия.', '', 0, 0, 180),
(181, 'Linda', '', 0, 0, 181),
(182, 'shokalat', 'шоколад', 2, 0, 182),
(183, 'shokolad', 'шоколад', 2, 0, 183),
(184, 'Barcha maxsulotlar', 'Все продукты', 2, 0, 184),
(185, 'benuqson ishlash va zavqning beqiyos ta\'mi!', 'безупречность исполнения и непревзойденный вкус удовольствия!', 2, 0, 185),
(186, '"Lindo Confectionery" - bu yuqori sifat, eng mayda detallarda puxtalik,', '«Lindo Confectionery» - это традиции высокого качества, тшательность в мельчайших деталях,', 2, 0, 186),
(187, 'Shirinliklarni ishlab chiqishda, birinchi navbatda, biz iste\'molchilarimiz haqida o\'ylaymiz.', 'Разрабатывая сладости, прежде всего, мы думаем о наших потребителях.', 2, 0, 187),
(188, 'Mahsulotlarimiz har bir xonadonga quvonch va ko\'proq baxt olib kelishini istaymiz!', 'Мы хотим, что бы наши изделия приносили радость в каждый дом, и счастья становилось больше!', 2, 0, 188),
(189, 'Biz mukammallikka intilishda to\'xtamasdan,', 'Не останавливаясь в своем стремлении к совершенству,', 2, 0, 189),
(190, 'professional ish va tabiiy ingredientlarni birlashtiramiz.', 'мы сочетаем профессиональную работу и натуральные ингредиенты.', 2, 0, 190),
(191, 'Bizning asosiy tamoyillarimiz:', 'Наши основные принципы:', 2, 0, 191),
(192, '• Biz faqat yuqori sifatli xom ashyolardan foydalanamiz;', '• используем только высококачественное сырье;', 2, 0, 192),
(193, '• Tayyor mahsulot sifatini nazorat qilishga e\'tibor qaratish;', '• концентрируем внимание на контроле качества готовой продукции;', 2, 0, 193),
(194, '• Biz narx va sifatning maqbul kombinatsiyasiga erishishga intilamiz;', '• стремимся к достижению оптимального сочетания цена — качество;', 2, 0, 194),
(195, '• Yangi g\'oyalarni izlash.', '• поиск новых идей.', 2, 0, 195),
(196, '“Lindo qandolatchilik” korxonasining rivojlanish rejalarida', 'В планах развития «Lindo Confectionery» увеличение доли продукции на кондитерском рынке', 2, 0, 196),
(197, 'O‘zbekiston Respublikasi qandolat bozorida mahsulot ulushini oshirish, ishlab chiqarishni modernizatsiya qilish va ishlab chiqarishning texnologik', 'Республики Узбекистан, модернизация производства и совершенствование технологических   процессов производства.', 2, 0, 197),
(198, 'jarayonlarini takomillashtirish ko‘zda tutilgan.', 'Особое внимание будет уделяться также', 2, 0, 198),
(199, 'Muhimlaridan biri sifatida savdo tizimiga ham alohida e\'tibor qaratiladi\r\n                            korxonaning samarali faoliyatining tarkibiy qismlariga.', 'системе продаж, как одной из важных составляющих эффективной деятельности предприятия.', 2, 0, 199),
(200, 'Mexir bilan tayyorlangan shirinliklar', 'Сладости сделанные с душой', 2, 0, 200) ;
INSERT INTO `wp_trp_dictionary_uz_uz_ru_ru` ( `id`, `original`, `translated`, `status`, `block_type`, `original_id`) VALUES
(201, 'Mexir bilan tayyorlangan shirinliklarT', '', 0, 0, 201),
(202, 'Qo\'ngiroq qilish', 'Позвонить', 2, 0, 202),
(203, 'sms://+998993045475', '', 0, 0, 203),
(204, 'mailto: lindo@lindo.uz', '', 0, 0, 204),
(205, 'sostav', '', 0, 0, 205),
(206, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque autem cupiditate quas quibusdam quidem\r\n                    recusandae saepe soluta, vero! Accusamus accusantium ad amet animi architecto consequuntur dolore\r\n                    dolores error, est excepturi, exercitationem fugiat inventore maxime, nam necessitatibus pariatur\r\n                    placeat reiciendis rem sapiente similique tempora velit voluptas voluptatum? Aperiam asperiores at\r\n                    consectetur consequuntur culpa debitis, delectus earum, eligendi est eveniet fuga fugiat illo in,\r\n                    inventore labore minus nisi nulla officia omnis pariatur praesentium quae quam quas quasi quis\r\n                    recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!harum magnam officia quia similique tempore, unde vel velit voluptatum!recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!', '', 0, 0, 206),
(207, 'Email orqali xabar jo\'nating', 'Отправить сообщение по электронной почте', 2, 0, 207),
(208, 'Xabarni yuborish', '', 0, 0, 208),
(209, 'tel:+998998556665', '', 0, 0, 209) ;

#
# End of data contents of table `wp_trp_dictionary_uz_uz_ru_ru`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_gettext_original_meta`
#

DROP TABLE IF EXISTS `wp_trp_gettext_original_meta`;


#
# Table structure of table `wp_trp_gettext_original_meta`
#

CREATE TABLE `wp_trp_gettext_original_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  UNIQUE KEY `meta_id` (`meta_id`),
  KEY `gettext_index_original_id` (`original_id`),
  KEY `gettext_meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_gettext_original_meta`
#

#
# End of data contents of table `wp_trp_gettext_original_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_gettext_original_strings`
#

DROP TABLE IF EXISTS `wp_trp_gettext_original_strings`;


#
# Table structure of table `wp_trp_gettext_original_strings`
#

CREATE TABLE `wp_trp_gettext_original_strings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `domain` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` text COLLATE utf8mb4_unicode_520_ci,
  `original_plural` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `gettext_index_original` (`original`(100))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_gettext_original_strings`
#
INSERT INTO `wp_trp_gettext_original_strings` ( `id`, `original`, `domain`, `context`, `original_plural`) VALUES
(1, 'Edit Profile', 'default', 'trp_context', ''),
(2, 'Log Out', 'default', 'trp_context', ''),
(3, 'Search', 'default', 'trp_context', ''),
(4, 'Howdy, %s', 'default', 'trp_context', ''),
(5, 'About WordPress', 'default', 'trp_context', ''),
(6, 'WordPress.org', 'default', 'trp_context', ''),
(7, 'https://wordpress.org/', 'default', 'trp_context', ''),
(8, 'Documentation', 'default', 'trp_context', ''),
(9, 'https://wordpress.org/support/', 'default', 'trp_context', ''),
(10, 'Support', 'default', 'trp_context', ''),
(11, 'https://wordpress.org/support/forums/', 'default', 'trp_context', ''),
(12, 'Feedback', 'default', 'trp_context', ''),
(13, 'https://wordpress.org/support/forum/requests-and-feedback', 'default', 'trp_context', ''),
(14, 'Dashboard', 'default', 'trp_context', ''),
(15, 'Themes', 'default', 'trp_context', ''),
(16, 'Customize', 'default', 'trp_context', ''),
(17, '%d Plugin Update', 'default', 'trp_context', '%d Plugin Updates'),
(18, 'Translation Updates', 'default', 'trp_context', ''),
(19, '%s update available', 'default', 'trp_context', '%s updates available'),
(20, '%s Comment in moderation', 'default', 'trp_context', '%s Comments in moderation'),
(21, 'User', 'default', 'add new from admin bar', ''),
(22, 'New', 'default', 'admin bar menu group label', ''),
(23, 'Skip to toolbar', 'default', 'trp_context', ''),
(24, 'Toolbar', 'default', 'trp_context', '') ;

#
# End of data contents of table `wp_trp_gettext_original_strings`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_gettext_ru_ru`
#

DROP TABLE IF EXISTS `wp_trp_gettext_ru_ru`;


#
# Table structure of table `wp_trp_gettext_ru_ru`
#

CREATE TABLE `wp_trp_gettext_ru_ru` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext COLLATE utf8mb4_unicode_520_ci,
  `domain` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` int(20) DEFAULT NULL,
  `original_id` bigint(20) DEFAULT NULL,
  `plural_form` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `index_name` (`original`(100)),
  FULLTEXT KEY `original_fulltext` (`original`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_gettext_ru_ru`
#
INSERT INTO `wp_trp_gettext_ru_ru` ( `id`, `original`, `translated`, `domain`, `status`, `original_id`, `plural_form`) VALUES
(1, 'Edit Profile', 'Изменить профиль', 'default', 2, 1, 0),
(2, 'Log Out', 'Выйти', 'default', 2, 2, 0),
(3, 'Search', 'Поиск', 'default', 2, 3, 0),
(4, 'Howdy, %s', 'Привет, %s', 'default', 2, 4, 0),
(5, 'About WordPress', 'О WordPress', 'default', 2, 5, 0),
(6, 'WordPress.org', '', 'default', 0, 6, 0),
(7, 'https://wordpress.org/', 'https://ru.wordpress.org/', 'default', 2, 7, 0),
(8, 'Documentation', 'Документация', 'default', 2, 8, 0),
(9, 'https://wordpress.org/support/', 'https://ru.wordpress.org/support/', 'default', 2, 9, 0),
(10, 'Support', 'Поддержка', 'default', 2, 10, 0),
(11, 'https://wordpress.org/support/forums/', 'https://ru.wordpress.org/support/forums/', 'default', 2, 11, 0),
(12, 'Feedback', 'Обратная связь', 'default', 2, 12, 0),
(13, 'https://wordpress.org/support/forum/requests-and-feedback', 'https://ru.wordpress.org/support/forum/requests-and-feedback/', 'default', 2, 13, 0),
(14, 'Dashboard', 'Консоль', 'default', 2, 14, 0),
(15, 'Themes', 'Темы', 'default', 2, 15, 0),
(16, 'Customize', 'Настроить', 'default', 2, 16, 0),
(17, '%d Plugin Update', '%d обновления плагинов', 'default', 2, 17, 1),
(18, 'Translation Updates', 'Обновления переводов', 'default', 2, 18, 0),
(19, '%s update available', 'Доступно %s обновления', 'default', 2, 19, 1),
(20, '%s Comment in moderation', '%s комментариев ждут одобрения', 'default', 2, 20, 2),
(21, 'User', 'Пользователя', 'default', 2, 21, 0),
(22, 'New', 'Добавить', 'default', 2, 22, 0),
(23, 'Skip to toolbar', 'Перейти к верхней панели', 'default', 2, 23, 0),
(24, 'Toolbar', 'Верхняя панель', 'default', 2, 24, 0) ;

#
# End of data contents of table `wp_trp_gettext_ru_ru`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_gettext_uz_uz`
#

DROP TABLE IF EXISTS `wp_trp_gettext_uz_uz`;


#
# Table structure of table `wp_trp_gettext_uz_uz`
#

CREATE TABLE `wp_trp_gettext_uz_uz` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext COLLATE utf8mb4_unicode_520_ci,
  `domain` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` int(20) DEFAULT NULL,
  `original_id` bigint(20) DEFAULT NULL,
  `plural_form` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `index_name` (`original`(100)),
  FULLTEXT KEY `original_fulltext` (`original`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_gettext_uz_uz`
#
INSERT INTO `wp_trp_gettext_uz_uz` ( `id`, `original`, `translated`, `domain`, `status`, `original_id`, `plural_form`) VALUES
(1, 'Edit Profile', 'Profilni tahrirlash', 'default', 2, 1, 0),
(2, 'Log Out', 'Chiqish', 'default', 2, 2, 0),
(3, 'Search', 'Izlash', 'default', 2, 3, 0),
(4, 'Howdy, %s', 'Salom, %s', 'default', 2, 4, 0),
(5, 'About WordPress', 'WordPress haqida', 'default', 2, 5, 0),
(6, 'WordPress.org', '', 'default', 0, 6, 0),
(7, 'https://wordpress.org/', '', 'default', 0, 7, 0),
(8, 'Documentation', 'Qo&lsquo;llanma', 'default', 2, 8, 0),
(9, 'https://wordpress.org/support/', '', 'default', 0, 9, 0),
(10, 'Support', 'Yordam', 'default', 2, 10, 0),
(11, 'https://wordpress.org/support/forums/', '', 'default', 0, 11, 0),
(12, 'Feedback', 'Fikr bildirish', 'default', 2, 12, 0),
(13, 'https://wordpress.org/support/forum/requests-and-feedback', '', 'default', 0, 13, 0),
(14, 'Dashboard', 'Boshqaruv paneli', 'default', 2, 14, 0),
(15, 'Themes', 'Shablonlar', 'default', 2, 15, 0),
(16, 'Customize', 'Moslashtirish', 'default', 2, 16, 0),
(17, '%d Plugin Update', '%d Plaginni yangilash', 'default', 2, 17, 0),
(18, 'Translation Updates', 'Tarjima yangilanishlari', 'default', 2, 18, 0),
(19, '%s update available', '', 'default', 0, 19, 0),
(20, '%s Comment in moderation', '%s ta fikr tekshiruvda', 'default', 2, 20, 0),
(21, 'User', 'Foydalanuvchi', 'default', 2, 21, 0),
(22, 'New', 'Yangi', 'default', 2, 22, 0),
(23, 'Skip to toolbar', 'Uskunalar paneliga o\'tish', 'default', 2, 23, 0),
(24, 'Toolbar', 'Uskunalar paneli', 'default', 2, 24, 0) ;

#
# End of data contents of table `wp_trp_gettext_uz_uz`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_original_meta`
#

DROP TABLE IF EXISTS `wp_trp_original_meta`;


#
# Table structure of table `wp_trp_original_meta`
#

CREATE TABLE `wp_trp_original_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  UNIQUE KEY `meta_id` (`meta_id`),
  KEY `index_original_id` (`original_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_original_meta`
#

#
# End of data contents of table `wp_trp_original_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_trp_original_strings`
#

DROP TABLE IF EXISTS `wp_trp_original_strings`;


#
# Table structure of table `wp_trp_original_strings`
#

CREATE TABLE `wp_trp_original_strings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `original` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_original` (`original`(100))
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_trp_original_strings`
#
INSERT INTO `wp_trp_original_strings` ( `id`, `original`) VALUES
(1, 'About us'),
(2, 'Products'),
(3, 'Contacts'),
(4, 'LINDO'),
(5, 'Glazurlangan pecheniya karameli bilan'),
(6, 'Bog\'lanish'),
(7, 'Milano'),
(8, 'shokoladli konfetlar'),
(9, 'Sweet & Milk'),
(10, 'Billion'),
(11, 'Feel'),
(12, 'Victoria'),
(13, 'LINDA'),
(14, 'Linda shkalat'),
(15, 'kg shokalat'),
(16, 'Prezident'),
(17, 'kg shkalat'),
(18, 'Lindo Plitka'),
(19, 'button'),
(20, 'СЛАДОСТИ СДЕЛАННЫЕ\r\n                    С ДУШОЙ'),
(21, 'Florentis'),
(22, 'Benicia'),
(23, 'Muhtasem'),
(24, 'Levante'),
(25, 'President'),
(26, 'Sweet&Milk'),
(27, '360°'),
(28, 'Delice'),
(29, 'Compete'),
(30, 'Chocolay'),
(31, '360° kg'),
(32, 'Палочка'),
(33, 'Hi-Tech'),
(34, 'Cappuccino'),
(35, 'LOCHIRA'),
(36, 'KUNJUTLI'),
(37, 'HI-TECH'),
(38, 'КОРОВКА'),
(39, 'ЮБИЛЕЙНОЕ'),
(40, 'Топленое'),
(41, 'Coffee'),
(42, 'view more'),
(43, 'Lindo'),
(44, '«Lindo Confectionery» - это традиции высокого качества, тшательность в мельчайших деталях,\r\n                            безупречность исполнения и непревзойденный вкус удовольствия!\r\n                            Разрабатывая сладости, прежде всего, мы думаем о наших потребителях. Мы хотим, что бы наши\r\n                            изделия приносили радость в каждый дом, и счастья становилось больше!\r\n                            Не останавливаясь в своем стремлении к совершенству, мы сочетаем\r\n                            профессиональную работу и натуральные ингредиенты.\r\n                            Наши основные принципы:\r\n                            • используем только высококачественное сырье;\r\n                            • концентрируем внимание на контроле качества готовой продукции;\r\n                            • стремимся к достижению оптимального сочетания цена — качество;\r\n                            • поиск новых идей.\r\n                            В планах развития «Lindo Confectionery» увеличение доли продукции на кондитерском рынке\r\n                            Республики Узбекистан, модернизация производства и совершенствование технологических\r\n                            процессов производства.\r\n                            Особое внимание будет уделяться также системе продаж, как одной из важных\r\n                            составляющих эффективной деятельности предприятия.'),
(45, 'LINDO email'),
(46, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio laborum praesentium\r\n                            suscipit!'),
(47, 'Izox qoldirish'),
(48, 'Izox'),
(49, 'izox'),
(50, 'Biz bilan telefon orqali aloqaga chiqing'),
(51, 'LINDO Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum molestias,\r\n                                quidem.'),
(52, 'Telefon nomer'),
(53, 'LINDO chocalate'),
(54, 'plato.uz'),
(55, 'http://lindo/wp-content/themes/lindo/assets/img/lindoLogo.png'),
(56, 'https://img.icons8.com/color/48/000000/uzbekistan.png'),
(57, 'https://img.icons8.com/color/48/000000/russian-federation.png'),
(58, 'https://img.icons8.com/color/48/000000/usa.png'),
(59, 'http://lindo/wp-content/themes/lindo/assets/img/remove/360.png'),
(60, 'http://lindo/wp-content/themes/lindo/assets/img/remove/milano.png'),
(61, 'http://lindo/wp-content/themes/lindo/assets/img/remove/sweet&milk.png'),
(62, 'http://lindo/wp-content/themes/lindo/assets/img/remove/billion.png'),
(63, 'http://lindo/wp-content/themes/lindo/assets/img/remove/feel.png'),
(64, 'http://lindo/wp-content/themes/lindo/assets/img/remove/vectoria.png'),
(65, 'http://lindo/wp-content/themes/lindo/assets/img/remove/lindoShkalat.png'),
(66, 'http://lindo/wp-content/themes/lindo/assets/img/remove/prezident.png'),
(67, 'http://lindo/wp-content/themes/lindo/assets/img/remove/lindoPlitka.png'),
(68, 'http://lindo/wp-content/uploads/2022/10/1.png'),
(69, 'http://lindo/wp-content/uploads/2022/10/2.png'),
(70, 'http://lindo/wp-content/uploads/2022/10/3.png'),
(71, 'http://lindo/wp-content/uploads/2022/10/5.png'),
(72, 'http://lindo/wp-content/uploads/2022/10/6.png'),
(73, 'http://lindo/wp-content/uploads/2022/10/7.png'),
(74, 'http://lindo/wp-content/uploads/2022/10/8.png'),
(75, 'http://lindo/wp-content/uploads/2022/10/10.png'),
(76, 'http://lindo/wp-content/uploads/2022/10/11.png'),
(77, 'http://lindo/wp-content/uploads/2022/10/9.png'),
(78, 'http://lindo/wp-content/uploads/2022/10/12.png'),
(79, 'http://lindo/wp-content/uploads/2022/10/13.png'),
(80, 'http://lindo/wp-content/uploads/2022/10/14.png'),
(81, 'http://lindo/wp-content/uploads/2022/10/15.png'),
(82, 'http://lindo/wp-content/uploads/2022/10/16.png'),
(83, 'http://lindo/wp-content/uploads/2022/10/17.png'),
(84, 'http://lindo/wp-content/uploads/2022/10/18.png'),
(85, 'http://lindo/wp-content/uploads/2022/10/19.png'),
(86, 'http://lindo/wp-content/uploads/2022/10/20.png'),
(87, 'http://lindo/wp-content/uploads/2022/10/21.png'),
(88, 'http://lindo/wp-content/uploads/2022/10/22.png'),
(89, 'http://lindo/wp-content/uploads/2022/10/23.png'),
(90, 'http://lindo/wp-content/uploads/2022/10/24.png'),
(91, 'http://lindo/wp-content/uploads/2022/10/25.png'),
(92, 'http://lindo/wp-content/uploads/2022/10/27.png'),
(93, 'http://lindo/wp-content/uploads/2022/10/26.png'),
(94, 'http://lindo/wp-content/uploads/2022/10/29.png'),
(95, 'http://lindo/wp-content/uploads/2022/10/28.png'),
(96, 'http://lindo/wp-content/uploads/2022/10/30.png'),
(97, 'http://lindo/wp-content/uploads/2022/10/Lindo-catalog-NEW-2.png'),
(98, 'tel:+9981234567'),
(99, 'https://platogroup.uz'),
(100, '1 of 30') ;
INSERT INTO `wp_trp_original_strings` ( `id`, `original`) VALUES
(101, '2 of 30'),
(102, '3 of 30'),
(103, '4 of 30'),
(104, '5 of 30'),
(105, '6 of 30'),
(106, '7 of 30'),
(107, '8 of 30'),
(108, '9 of 30'),
(109, '10 of 30'),
(110, '11 of 30'),
(111, '12 of 30'),
(112, '13 of 30'),
(113, '14 of 30'),
(114, '15 of 30'),
(115, '16 of 30'),
(116, '17 of 30'),
(117, '18 of 30'),
(118, '19 of 30'),
(119, '20 of 30'),
(120, '21 of 30'),
(121, '22 of 30'),
(122, '23 of 30'),
(123, '24 of 30'),
(124, '25 of 30'),
(125, '26 of 30'),
(126, '27 of 30'),
(127, '28 of 30'),
(128, '29 of 30'),
(129, '30 of 30'),
(130, 'Go to last slide'),
(131, 'Next slide'),
(132, 'Select a slide to show'),
(133, 'Go to slide 1'),
(134, 'Go to slide 2'),
(135, 'Go to slide 3'),
(136, 'Go to slide 4'),
(137, 'Go to slide 5'),
(138, 'Go to slide 6'),
(139, 'Go to slide 7'),
(140, 'Go to slide 8'),
(141, 'Go to slide 9'),
(142, 'Go to slide 10'),
(143, 'Go to slide 11'),
(144, 'Go to slide 12'),
(145, 'Go to slide 13'),
(146, 'Go to slide 14'),
(147, 'Go to slide 15'),
(148, 'Go to slide 16'),
(149, 'Go to slide 17'),
(150, 'Go to slide 18'),
(151, 'Go to slide 19'),
(152, 'Go to slide 20'),
(153, 'Go to slide 21'),
(154, 'Go to slide 22'),
(155, 'Go to slide 23'),
(156, 'Go to slide 24'),
(157, 'Go to slide 25'),
(158, 'Go to slide 26'),
(159, 'Go to slide 27'),
(160, 'Go to slide 28'),
(161, 'Go to slide 29'),
(162, 'Go to slide 30'),
(163, 'Biz haqimizda'),
(164, 'Maxsulotlar'),
(165, 'Biz bilan aloqa'),
(166, '«Lindo Confectionery» - это традиции высокого качества, тшательность в мельчайших деталях,'),
(167, 'безупречность исполнения и непревзойденный вкус удовольствия!'),
(168, 'Разрабатывая сладости, прежде всего, мы думаем о наших потребителях. Мы хотим, что бы наши'),
(169, 'изделия приносили радость в каждый дом, и счастья становилось больше!'),
(170, 'Не останавливаясь в своем стремлении к совершенству, мы сочетаем'),
(171, 'профессиональную работу и натуральные ингредиенты.'),
(172, 'Наши основные принципы:'),
(173, '• используем только высококачественное сырье;'),
(174, '• концентрируем внимание на контроле качества готовой продукции;'),
(175, '• стремимся к достижению оптимального сочетания цена — качество;'),
(176, '• поиск новых идей.'),
(177, 'В планах развития «Lindo Confectionery» увеличение доли продукции на кондитерском рынке'),
(178, 'Республики Узбекистан, модернизация производства и совершенствование технологических'),
(179, 'процессов производства.'),
(180, 'Особое внимание будет уделяться также системе продаж, как одной из важных\r\n                            составляющих эффективной деятельности предприятия.'),
(181, 'Linda'),
(182, 'shokalat'),
(183, 'shokolad'),
(184, 'Barcha maxsulotlar'),
(185, 'benuqson ishlash va zavqning beqiyos ta\'mi!'),
(186, '"Lindo Confectionery" - bu yuqori sifat, eng mayda detallarda puxtalik,'),
(187, 'Shirinliklarni ishlab chiqishda, birinchi navbatda, biz iste\'molchilarimiz haqida o\'ylaymiz.'),
(188, 'Mahsulotlarimiz har bir xonadonga quvonch va ko\'proq baxt olib kelishini istaymiz!'),
(189, 'Biz mukammallikka intilishda to\'xtamasdan,'),
(190, 'professional ish va tabiiy ingredientlarni birlashtiramiz.'),
(191, 'Bizning asosiy tamoyillarimiz:'),
(192, '• Biz faqat yuqori sifatli xom ashyolardan foydalanamiz;'),
(193, '• Tayyor mahsulot sifatini nazorat qilishga e\'tibor qaratish;'),
(194, '• Biz narx va sifatning maqbul kombinatsiyasiga erishishga intilamiz;'),
(195, '• Yangi g\'oyalarni izlash.'),
(196, '“Lindo qandolatchilik” korxonasining rivojlanish rejalarida'),
(197, 'O‘zbekiston Respublikasi qandolat bozorida mahsulot ulushini oshirish, ishlab chiqarishni modernizatsiya qilish va ishlab chiqarishning texnologik'),
(198, 'jarayonlarini takomillashtirish ko‘zda tutilgan.'),
(199, 'Muhimlaridan biri sifatida savdo tizimiga ham alohida e\'tibor qaratiladi\r\n                            korxonaning samarali faoliyatining tarkibiy qismlariga.'),
(200, 'Mexir bilan tayyorlangan shirinliklar') ;
INSERT INTO `wp_trp_original_strings` ( `id`, `original`) VALUES
(201, 'Mexir bilan tayyorlangan shirinliklarT'),
(202, 'Qo\'ngiroq qilish'),
(203, 'sms://+998993045475'),
(204, 'mailto: lindo@lindo.uz'),
(205, 'sostav'),
(206, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque autem cupiditate quas quibusdam quidem\r\n                    recusandae saepe soluta, vero! Accusamus accusantium ad amet animi architecto consequuntur dolore\r\n                    dolores error, est excepturi, exercitationem fugiat inventore maxime, nam necessitatibus pariatur\r\n                    placeat reiciendis rem sapiente similique tempora velit voluptas voluptatum? Aperiam asperiores at\r\n                    consectetur consequuntur culpa debitis, delectus earum, eligendi est eveniet fuga fugiat illo in,\r\n                    inventore labore minus nisi nulla officia omnis pariatur praesentium quae quam quas quasi quis\r\n                    recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!harum magnam officia quia similique tempore, unde vel velit voluptatum!recusandae rem repellat sapiente sed sit sunt tempora tenetur voluptatum. Aliquid autem dolore fuga\r\n                    harum magnam officia quia similique tempore, unde vel velit voluptatum!'),
(207, 'Email orqali xabar jo\'nating'),
(208, 'Xabarni yuborish'),
(209, 'tel:+998998556665') ;

#
# End of data contents of table `wp_trp_original_strings`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'lindo'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '162'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'session_tokens', 'a:1:{s:64:"e5c361f5e47a3e91a10c97853984b72a539f234289c77da6df6e9cec6a4238bd";a:4:{s:10:"expiration";i:1683534717;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1683361917;}}'),
(20, 1, 'meta-box-order_acf-field-group', 'a:3:{s:4:"side";s:22:"acf-field-group-fields";s:6:"normal";s:60:"acf-field-group-pro-features,acf-field-group-options,slugdiv";s:8:"advanced";s:0:"";}'),
(21, 1, 'screen_layout_acf-field-group', '1'),
(22, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(23, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}'),
(24, 1, 'wp_user-settings', 'libraryContent=browse'),
(25, 1, 'wp_user-settings-time', '1665337851'),
(26, 1, 'trp_email_course_dismissed', '1'),
(27, 1, 'trp_new_feature_string_translation_dismiss_notification', 'true'),
(28, 1, 'trp_language', 'ru_RU'),
(29, 1, 'trp_always_use_this_language', 'no') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'lindo', '$P$BZH/C9UG1cITEo3t0F/.eK/AWKtTWr1', 'lindo', 'xibroxim11@gmail.com', 'http://lindo', '2022-09-28 18:03:51', '', 0, 'lindo') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

